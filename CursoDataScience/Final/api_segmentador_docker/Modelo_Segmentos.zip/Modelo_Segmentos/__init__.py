# Paquete de segmentación de clientes
