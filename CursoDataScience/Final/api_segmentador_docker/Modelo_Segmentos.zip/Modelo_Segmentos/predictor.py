import pickle
import pandas as pd
import os

# Ruta de archivos dentro del paquete
ASSET_PATH = os.path.join(os.path.dirname(__file__), 'assets')

# Cargar modelo, scaler y encoders
with open(os.path.join(ASSET_PATH, 'kmeans.pkl'), 'rb') as f:
    kmeans = pickle.load(f)

with open(os.path.join(ASSET_PATH, 'scaler.pkl'), 'rb') as f:
    scaler = pickle.load(f)

with open(os.path.join(ASSET_PATH, 'encoder.pkl'), 'rb') as f:
    encoders = pickle.load(f)

def predecir_segmento(cliente: dict) -> int:
    """
    Recibe un diccionario con los datos del cliente (snake_case)
    y devuelve el número de segmento (clúster) correspondiente.
    """
    df = pd.DataFrame([cliente])

    # Codificar variables categóricas
    for col in ['gender', 'customer_type', 'product_line', 'payment', 'city', 'branch']:
        if col in df.columns:
            le = encoders.get(col)
            if le:
                try:
                    df[col] = le.transform(df[col])
                except ValueError as e:
                    print(f"❌ Valor no válido en '{col}': {df[col].values[0]} - {e}")
                    return None

    # Orden exacto de columnas usadas durante entrenamiento
    columnas_orden = [
        'gender', 'customer_type', 'product_line', 'unit_price',
        'quantity', 'payment', 'city', 'branch',
        'hour', 'weekday', 'month', 'avgprice'
    ]

    # Validar columnas
    missing = set(columnas_orden) - set(df.columns)
    if missing:
        print(f"❌ Faltan columnas en el input: {missing}")
        return None

    df = df[columnas_orden]

    # Mostrar para depuración
    print("📋 Columnas ordenadas:", df.columns.tolist())
    print("📊 Valores del cliente:", df.to_dict(orient='records')[0])

    try:
        # Escalar (ignorando nombres de columnas)
        X_scaled = scaler.transform(df.to_numpy())

        # Predecir clúster
        cluster = int(kmeans.predict(X_scaled)[0])
        return cluster
    except Exception as e:
        print("❌ Error durante la predicción:", e)
        return None
