from setuptools import setup, find_packages

setup(
    name='Modelo_Segmentos',
    version='1.0',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'Modelo_Segmentos': ['assets/*.pkl']
    },
    install_requires=[
        'pandas',
        'scikit-learn'
    ],
    author='Alan Buendia',
    description='Librería para segmentar clientes usando KMeans'
)
