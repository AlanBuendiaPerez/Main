import requests
import os

# Token de Acceso Personal (App Password)
token = 'ATCTT3xFfGN00NCJunm-mXtYoBuLsTW6YhlTkcG4Mymkz8q9Os7o2ShZQ-aj2_LDe2UJLBboqSlckx5lPQCXajEer2UzgiSLYChMH-QJqSbvcT6MizW8Y0ucHUZRTC1bzwDtAP-vpoQm59FNLuozvg4a_2ZHEu1YBa4ukjomDdCEG7mXboS94rA=11D7EF58'

# Información del repositorio
repo_owner = 'ibkteam'
repo_slug = 'ati-st'
branch = 'master'
directory = 'Cambio Estado'

# Encabezado de autorización utilizando el token
headers = {
    'Authorization': f'Bearer {token}'
}

def download_file(file_url, local_path):
    response = requests.get(file_url, headers=headers)
    if response.status_code == 200:
        with open(local_path, 'wb') as f:
            f.write(response.content)
        print(f'Descargado: {local_path}')
    else:
        print(f'Error al descargar: {local_path} - Status code: {response.status_code}')

def download_directory(api_url, local_dir):
    response = requests.get(api_url, headers=headers)
    if response.status_code == 200:
        files = response.json()['values']

        for file in files:
            file_path = file['path']
            file_url = file['links']['self']['href']
            local_path = os.path.join(local_dir, os.path.normpath(file_path.replace(directory + '/', '')))

            if file['type'] == 'commit_file':
                # Es un archivo, descargarlo
                os.makedirs(os.path.dirname(local_path), exist_ok=True)
                download_file(file_url, local_path)
            elif file['type'] == 'commit_directory':
                # Es un directorio, descargar recursivamente
                new_api_url = f'https://api.bitbucket.org/2.0/repositories/{repo_owner}/{repo_slug}/src/{branch}/{file_path}/'
                download_directory(new_api_url, local_dir)

# URL de la API para listar los archivos en la carpeta
api_url = f'https://api.bitbucket.org/2.0/repositories/{repo_owner}/{repo_slug}/src/{branch}/{directory}/'

# Crear la carpeta local si no existe
os.makedirs(directory, exist_ok=True)

# Descargar la carpeta especificada
download_directory(api_url, directory)

print("Descarga completada.")