import pandas as pd
import mysql.connector
import os

# Función para actualizar productos
def actualizar_productos(file_path, tipo):
    # Validar que el archivo existe
    if not os.path.isfile(file_path):
        print(f"El archivo {file_path} no existe.")
        return

    try:
        # Leer el archivo CSV con la codificación adecuada y manejar líneas problemáticas
        df = pd.read_csv(file_path, encoding='ISO-8859-1', sep=';', on_bad_lines='skip')

        # Imprimir las columnas del archivo para verificar la presencia de 'PRODUCTO'
        print(f"Columnas en {file_path}: {df.columns.tolist()}")

        # Verificar si la columna 'PRODUCTO' existe
        if 'PRODUCTO' not in df.columns:
            print(f"El archivo {file_path} no contiene la columna 'PRODUCTO'.")
            return

        # Obtener los datos de la columna PRODUCTO
        productos = df['PRODUCTO'].tolist()

        # Obtener lista sin repetidos
        productos_unicos = list(set(productos))

        # Conectar a la base de datos MySQL
        conn = mysql.connector.connect(
            host='localhost',  # Cambia esto por tu host de MySQL
            user='root',  # Cambia esto por tu usuario de MySQL
            password='',  # Cambia esto por tu contraseña de MySQL
            database='portalautomatizaciones'  # Cambia esto por tu base de datos de MySQL
        )

        cursor = conn.cursor()

        # Crear la consulta SQL para actualizar el estado de los productos donde tipo es el especificado
        placeholders = ', '.join(['%s'] * len(productos_unicos))
        update_query = f"UPDATE productos SET estado = 1 WHERE tipo = %s AND producto IN ({placeholders})"
        params = [tipo] + productos_unicos

        # Ejecutar la consulta
        cursor.execute(update_query, params)

        # Confirmar los cambios
        conn.commit()

        # Cerrar la conexión
        cursor.close()
        conn.close()

        print(f"Actualización completada para tipo {tipo}.")
    except pd.errors.ParserError as pe:
        print(f"Error al procesar el archivo {file_path}: {pe}")
    except Exception as e:
        print(f"Error al procesar el archivo {file_path}: {e}")

# Definir las rutas de los archivos y los tipos correspondientes
archivos_tipos = {
    r'C:\Users\x13579\Documents\Ibk\Data\IM-ListaCorrientes.csv': 1,
    r'C:\Users\x13579\Documents\Ibk\Data\ST-ListaAhorros.csv': 2,
    r'C:\Users\x13579\Documents\Ibk\Data\ST-ListaCBN.csv': 8,
    r'C:\Users\x13579\Documents\Ibk\Data\ST-ListaCTS.csv': 7,
    r'C:\Users\x13579\Documents\Ibk\Data\ST-ListaPlazos.csv': 6
}

# Actualizar productos para cada archivo y tipo correspondiente
for file_path, tipo in archivos_tipos.items():
    actualizar_productos(file_path, tipo)
