<?php
require_once 'src/BusinessLogic/business_logic.php';

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Obtener el ID del usuario desde la URL
$usuario_id = isset($_GET['usuario']) ? sanitize_input($_GET['usuario']) : '';

// Obtener datos de automatizaciones
$automatizaciones = get_filtered_automatizaciones();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.css">
    <style>
        .custom-navbar {
            background-color: #4caf50;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .custom-navbar .navbar-nav .nav-link {
            color: #fff !important;
        }
        table.dataTable thead .column-filter {
            width: 100%;
            padding: 3px;
            box-sizing: border-box;
            border: 1px solid #ccc;
        }
        table.dataTable {
            border-top: 2px solid #ddd;
        }
        .text-center {
            text-align: center;
        }
        .btn-circle {
            border-radius: 50%;
            width: 35px;
            height: 35px;
            padding: 6px;
            background-color: #28a745;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            border: none;
            margin: 0 auto;
        }
        .btn-circle i {
            color: #fff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top custom-navbar">
        <a class="navbar-brand text-white fw-bold" style="margin-left: 15px;">AUTOMATIZACIONES</a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="data.php?usuario=<?php echo $usuario_id; ?>">DATA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="automatizaciones.php?usuario=<?php echo $usuario_id; ?>">AUTOMATIZACIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="solicitudes.php?usuario=<?php echo $usuario_id; ?>">SOLICITUDES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="regresiones.php?usuario=<?php echo $usuario_id; ?>">REGRESIONES</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container-fluid mt-5 pt-4">
        <div class="row">
            <div class="col-md-12">
                <div id="table-container" class="table-responsive">
                    <table id="tablaResultados" class="table table-striped table-bordered nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Equipo</th>
                                <th>Funcionalidad</th>
                                <th>Aplicativo</th>
                                <th>Tipo Tecnología</th>
                                <th>Entorno Desarrollo</th>
                                <th class="text-center"></th>
                            </tr>
                            <tr>
                                <th><input type="text" placeholder="Buscar Equipo" class="form-control column-filter" data-column="0"></th>
                                <th><input type="text" placeholder="Buscar Funcionalidad" class="form-control column-filter" data-column="1"></th>
                                <th><input type="text" placeholder="Buscar Aplicativo" class="form-control column-filter" data-column="2"></th>
                                <th><input type="text" placeholder="Buscar Tipo Tecnología" class="form-control column-filter" data-column="3"></th>
                                <th><input type="text" placeholder="Buscar Entorno Desarrollo" class="form-control column-filter" data-column="4"></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($automatizaciones as $autom): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($autom['EQUIPO']); ?></td>
                                    <td><?php echo htmlspecialchars($autom['FUNCIONALIDAD']); ?></td>
                                    <td class="text-center"><?php echo htmlspecialchars($autom['APLICATIVO']); ?></td>
                                    <td class="text-center"><?php echo htmlspecialchars($autom['TECNOLOGIA']); ?></td>
                                    <td><?php echo htmlspecialchars($autom['ENTORNO']); ?></td>
                                    <td class="text-center">
                                        <form method="post" action="cargadatos.php" class="d-inline">
                                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($autom['ID']); ?>">
                                            <input type="hidden" name="equipo" value="<?php echo htmlspecialchars($autom['EQUIPO']); ?>">
                                            <input type="hidden" name="funcionalidad" value="<?php echo htmlspecialchars($autom['FUNCIONALIDAD']); ?>">
                                            <input type="hidden" name="aplicativo" value="<?php echo htmlspecialchars($autom['APLICATIVO']); ?>">
                                            <input type="hidden" name="tecnologia" value="<?php echo htmlspecialchars($autom['TECNOLOGIA']); ?>">
                                            <input type="hidden" name="entorno" value="<?php echo htmlspecialchars($autom['ENTORNO']); ?>">
                                            <input type="hidden" name="usuario" value="<?php echo htmlspecialchars($usuario_id); ?>">
                                            <button type="submit" class="btn-circle btn-primary"><i class="bi bi-arrow-right"></i></button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            var table = $('#tablaResultados').DataTable({
                responsive: true,
                lengthChange: false,
                paging: true,
                dom: 't'
            });

            $('.column-filter').on('keyup change', function() {
                var column = table.column($(this).data('column'));
                column.search(this.value).draw();
            });
        });
    </script>
</body>
</html>
