<?php

require_once '../src/BusinessLogic/business_logic.php';

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = sanitize_input($_POST['id']);
    $equipo = sanitize_input($_POST['equipo']);
    $funcionalidad = sanitize_input($_POST['funcionalidad']);
    $aplicativo = sanitize_input($_POST['aplicativo']);
    $tecnologia = sanitize_input($_POST['tecnologia']);
    $entorno = sanitize_input($_POST['entorno']);
    $usuario_id = sanitize_input($_POST['usuario']);
} else {
    echo "<h1>No se recibieron datos.</h1>";
    exit;
}

// Supongamos que esta es la función que obtendrá los datos para la cabecera
$cabeceras = get_filtered_parametrosentrada(['id_automatizacion' => $id]);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.css">
    <style>
        .custom-navbar {
            background-color: #4caf50;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .custom-navbar .navbar-nav .nav-link {
            color: #fff !important;
        }
        table.dataTable {
            border-top: 2px solid #ddd;
            width: 100% !important;
        }
        .text-center {
            text-align: center;
        }
        .btn-circle {
            border-radius: 50%;
            width: 35px;
            height: 35px;
            padding: 6px;
            background-color: #28a745;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            border: none;
            margin: 0 auto;
        }
        .btn-circle-remove {
            background-color: #dc3545;
        }
        .btn-circle-remove i {
            color: #fff;
        }
        .btn-circle i {
            color: #fff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top custom-navbar">
        <a class="navbar-brand text-white fw-bold" style="margin-left: 15px;">AUTOMATIZACIONES</a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="data.php?usuario=<?php echo $usuario_id; ?>">DATA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="automatizaciones.php?usuario=<?php echo $usuario_id; ?>">AUTOMATIZACIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="solicitudes.php?usuario=<?php echo $usuario_id; ?>">SOLICITUDES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="regresiones.php?usuario=<?php echo $usuario_id; ?>">REGRESIONES</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container mt-5 pt-4">
        <div id="table-container" class="table-responsive">
            <table id="tablaCabecera" class="table table-striped table-bordered nowrap" style="width:100%">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Equipo</th>
                        <th>Funcionalidad</th>
                        <th>Aplicativo</th>
                        <th>Tecnología</th>
                        <th>Entorno</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $id; ?></td>
                        <td><?php echo $equipo; ?></td>
                        <td><?php echo $funcionalidad; ?></td>
                        <td><?php echo $aplicativo; ?></td>
                        <td><?php echo $tecnologia; ?></td>
                        <td><?php echo $entorno; ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-md-12">
                <div id="table-container" class="table-responsive">
                    <table id="tablaParametros" class="table table-striped table-bordered nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <?php foreach ($cabeceras as $cabecera): ?>
                                    <th><?php echo htmlspecialchars($cabecera['NOMBRE_PARAMETRO']); ?></th>
                                <?php endforeach; ?>
                                <th class="text-center"><button id="addRowBtn" class="btn-circle"><i class="bi bi-plus"></i></button></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <?php foreach ($cabeceras as $cabecera): ?>
                                    <td contenteditable="true"></td>
                                <?php endforeach; ?>
                                <td class="text-center"><button class="btn-circle btn-circle-remove"><i class="bi bi-dash"></i></button></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <button id="saveBtn" class="btn btn-success mt-3">Grabar</button>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
        $(document).ready(function() {
            var table = $('#tablaParametros').DataTable({
                responsive: true,
                searching: false,
                lengthChange: false,
                paging: false,
                ordering: false // Deshabilita el ordenamiento
            });

            $('#addRowBtn').on('click', function() {
                var newRow = $('<tr>');
                <?php foreach ($cabeceras as $cabecera): ?>
                    newRow.append('<td contenteditable="true"></td>');
                <?php endforeach; ?>
                newRow.append('<td class="text-center"><button class="btn-circle btn-circle-remove"><i class="bi bi-dash"></i></button></td>');
                table.row.add(newRow).draw(false);
            });

            $('#tablaParametros tbody').on('click', '.btn-circle-remove', function() {
                table.row($(this).parents('tr')).remove().draw();
            });

            $('#saveBtn').on('click', function() {
                var tableData = [];
                var allFilled = true;
                var headers = [];

                $('#tablaParametros thead th').each(function() {
                    headers.push($(this).text().trim());
                });

                $('#tablaParametros tbody tr').each(function() {
                    var rowData = {};
                    $(this).find('td').each(function(index) {
                        if (index < <?php echo count($cabeceras); ?>) {
                            var cellValue = $(this).text();
                            if (cellValue === "") {
                                allFilled = false;
                            }
                            rowData[headers[index]] = cellValue;
                        }
                    });
                    tableData.push(rowData);
                });

                if (!allFilled) {
                    alert('Por favor, complete todos los campos antes de guardar.');
                    return;
                }

                var jsonData = JSON.stringify(tableData);

                $.ajax({
                    url: 'guardadata.php',
                    method: 'POST',
                    data: {
                        id_automatizacion: <?php echo $id; ?>,
                        parametros_entrada: jsonData,
                        estado: 1,
                        usuario: <?php echo json_encode($usuario_id); ?> // Pasar el usuario_id
                    },
                    success: function(response) {
                        var res = JSON.parse(response);
                        if (res.status === 'success') {
                            alert('Datos guardados correctamente');
                        } else {
                            alert('Error al guardar los datos: ' + res.message);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Error al guardar los datos: ' + error);
                    }
                });
            });
        });
    </script>
</body>
</html>
