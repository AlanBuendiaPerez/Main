<?php
// config.php
$host = 'localhost'; // o la dirección IP de tu servidor de base de datos
$db_name = 'portalautomatizaciones';
$user = 'root';
$password = '';
