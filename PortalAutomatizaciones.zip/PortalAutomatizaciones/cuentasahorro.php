<?php
session_start();
require_once 'src/BusinessLogic/business_logic.php';

if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');
}

if (!isset($_SESSION['usuario'])) {
    header('Location: index.php');
    exit;
}

$usuario_id = $_SESSION['usuario'];
$es_admin = isset($_SESSION['admin']) && $_SESSION['admin'];

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

$monedas_options = getOptions('monedas');
$productos_options = getOptions('productos');
$documentos_options = getOptions('documentos');
$estados_options = getOptions('estados');
$oficinas_options = getOptions('oficinas');
$restricciones_retiros_options = getOptions('restricciones_retiros');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['consultar']) && $_GET['consultar'] == '1') {
    $params = [
        'moneda' => isset($_GET['moneda']) ? sanitize_input($_GET['moneda']) : null,
        'oficina' => isset($_GET['oficina']) ? sanitize_input($_GET['oficina']) : null,
        'estado' => isset($_GET['estado']) ? sanitize_input($_GET['estado']) : null,
        'producto' => isset($_GET['producto']) ? sanitize_input($_GET['producto']) : null,
        'tipodoc' => isset($_GET['tipodoc']) ? sanitize_input($_GET['tipodoc']) : null,
        'restriccion' => isset($_GET['restriccion']) ? sanitize_input($_GET['restriccion']) : null
    ];

    if (validarParametros($params)) {
        $resultados = get_filtered_cuentasahorros($params);
        echo json_encode($resultados);
    } else {
        echo json_encode(['error' => 'Invalid parameters']);
    }
    exit;
}

function validarParametros($params) {
    foreach ($params as $param) {
        if ($param !== null && !preg_match('/^[a-zA-Z0-9_]+$/', $param)) {
            return false;
        }
    }
    return true;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <style>
        .custom-navbar {
            background-color: #4caf50;
        }
        .form-container {
            margin-bottom: 20px;
        }
        .btn-consultar, .btn-copy {
            background-color: #4caf50;
            color: #fff;
            margin-right: 10px;
            border: 2px solid #45a049;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .btn-consultar:hover, .btn-copy:hover {
            background-color: #45a049;
            border-color: #5cb85c;
        }
        .btn-consultar:active, .btn-copy:active {
            background-color: #5cb85c;
            border-color: #4caf50;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .custom-navbar .navbar-nav .nav-link {
            color: #fff !important;
        }
        .dataTables_wrapper .dataTables_filter {
            display: none;
        }
        table.dataTable thead .column-filter {
            width: 100%;
            padding: 3px;
            box-sizing: border-box;
            border: 1px solid #ccc;
        }
        table.dataTable thead th {
            white-space: nowrap;
        }
        table.dataTable {
            width: 100% !important;
            table-layout: auto;
            border: 1px solid #ddd;
        }
        table.dataTable td, table.dataTable th {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            border: 1px solid #ddd;
        }
        .spacing-top {
            margin-top: 2px;
        }
        .spacing-top-button {
            margin-top: -5px;
        }
        #loadingIndicator {
            position: absolute;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            display: none;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top custom-navbar">
        <a class="navbar-brand text-white fw-bold" style="margin-left: 15px;">CUENTAS DE AHORRO</a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="data.php">DATA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="automatizaciones.php">AUTOMATIZACIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="solicitudes.php">SOLICITUDES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="regresiones.php">REGRESIONES</a>
                </li>
                <?php if ($es_admin): ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="mantenimiento.php">MANTENIMIENTO</a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="logout.php">LOGOUT</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container-fluid mt-5 pt-4">
        <div class="row">
            <div class="col-md-12">
                <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="form-container" id="filterForm">
                    <div class="row">
                        <div class="col-md-2">
                            <label for="producto" style="font-weight: bold;">Producto</label>
                        </div>
                        <div class="col-md-2">
                            <label for="moneda" style="font-weight: bold;">Moneda</label>
                        </div>
                        <div class="col-md-2">
                            <label for="estado" style="font-weight: bold;">Estado</label>
                        </div>
                        <div class="col-md-2">
                            <label for="tipodoc" style="font-weight: bold;">Tipo de Documento</label>
                        </div>
                        <div class="col-md-2">
                            <label for="oficina" style="font-weight: bold;">Oficina</label>
                        </div>
                        <div class="col-md-2">
                            <label for="restriccion" style="font-weight: bold;">Restricción de Retiros</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2 spacing-top">
                            <select id="producto" name="producto" class="form-control">
                                <option value="" disabled selected>Seleccione el producto</option>
                                <?php echo $productos_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2 spacing-top">
                            <select id="moneda" name="moneda" class="form-control">
                                <option value="" disabled selected>Seleccione la moneda</option>
                                <?php echo $monedas_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2 spacing-top">
                            <select id="estado" name="estado" class="form-control">
                                <option value="" disabled selected>Seleccione el estado</option>
                                <?php echo $estados_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2 spacing-top">
                            <select id="tipodoc" name="tipodoc" class="form-control">
                                <option value="" disabled selected>Seleccione el tipo de documento</option>
                                <?php echo $documentos_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2 spacing-top">
                            <select id="oficina" name="oficina" class="form-control">
                                <option value="" disabled selected>Seleccione la oficina</option>
                                <?php echo $oficinas_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2 spacing-top">
                            <select id="restriccion" name="restriccion" class="form-control">
                                <option value="" disabled selected>Seleccione la restricción de retiros</option>
                                <?php echo $restricciones_retiros_options; ?>
                            </select>
                        </div>
                        <div class="col-md-1 spacing-top-button">
                            <label for="consultar" style="font-weight: bold;">&nbsp;</label>
                            <button type="submit" name="consultar" class="btn btn-consultar w-100">Consultar</button>
                        </div>
                    </div>
                </form>
                <div id="loadingIndicator">Cargando...</div>
                <div id="table-container" class="table-responsive d-none">
                    <table id="tablaResultados" class="table table-striped table-bordered nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Cuenta</th>
                                <th>Nro Cuenta</th>
                                <th>Codigo Unico</th>
                                <th>Nro Documento</th>
                                <th>Saldo Disponible</th>
                                <th>Saldo Contable</th>
                                <th>Fecha Apertura</th>
                                <th>Nombre</th>
                                <th></th>
                            </tr>
                            <tr>
                                <th><input type="text" placeholder="Buscar Cuenta" class="form-control column-filter" data-column="0"></th>
                                <th><input type="text" placeholder="Buscar NroCuenta" class="form-control column-filter" data-column="1"></th>
                                <th><input type="text" placeholder="Buscar Codigo Unico" class="form-control column-filter" data-column="2"></th>
                                <th><input type="text" placeholder="Buscar NroDocumento" class="form-control column-filter" data-column="3"></th>
                                <th><input type="text" placeholder="Buscar Disponible" class="form-control column-filter" data-column="4"></th>
                                <th><input type="text" placeholder="Buscar Contable" class="form-control column-filter" data-column="5"></th>
                                <th><input type="text" placeholder="Buscar Fecha Apertura" class="form-control column-filter" data-column="6"></th>
                                <th><input type="text" placeholder="Buscar Nombre" class="form-control column-filter" data-column="7"></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.10/clipboard.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            var table;

            function setSelectedValues() {
                $('#producto').val(localStorage.getItem('selectedProducto') || '');
                $('#moneda').val(localStorage.getItem('selectedMoneda') || '');
                $('#estado').val(localStorage.getItem('selectedEstado') || '');
                $('#tipodoc').val(localStorage.getItem('selectedTipodoc') || '');
                $('#oficina').val(localStorage.getItem('selectedOficina') || '');
                $('#restriccion').val(localStorage.getItem('selectedRestriccion') || '');
            }

            $('#filterForm').on('submit', function(event) {
                localStorage.setItem('selectedProducto', $('#producto').val());
                localStorage.setItem('selectedMoneda', $('#moneda').val());
                localStorage.setItem('selectedEstado', $('#estado').val());
                localStorage.setItem('selectedTipodoc', $('#tipodoc').val());
                localStorage.setItem('selectedOficina', $('#oficina').val());
                localStorage.setItem('selectedRestriccion', $('#restriccion').val());
            });

            $('#filterForm').on('submit', function(event) {
                event.preventDefault();
                if (table) {
                    table.clear().draw();
                }
                $('#table-container').addClass('d-none');
                $('#loadingIndicator').show();

                $.ajax({
                    url: '<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>',
                    method: 'GET',
                    data: $(this).serialize() + '&consultar=1&ajax=1',
                    dataType: 'json',
                    success: function(data) {
                        $('#loadingIndicator').hide();
                        $('#table-container').removeClass('d-none');
                        if (table) {
                            table.clear().rows.add(data).draw();
                        } else {
                            table = $('#tablaResultados').DataTable({
                                data: data,
                                columns: [
                                    { data: 'cuenta' },
                                    { data: 'nro_cuenta' },
                                    { data: 'cod_unico' },
                                    { data: 'nrodocumento' },
                                    { data: 'sdo_disponible' },
                                    { data: 'sdo_contable' },
                                    { data: 'fecha_apertura' },
                                    { data: 'nombre' },
                                    {
                                        data: null,
                                        defaultContent: '<button class="btn btn-copy" data-clipboard-text="">Copiar</button>'
                                    }
                                ],
                                "processing": true,
                                "serverSide": false,
                                "pageLength": 10,
                                "lengthChange": false,
                                "order": [],
                                "columnDefs": [
                                    { "orderable": false, "targets": [8] }
                                ],
                                "responsive": true,
                                "dom": 'tipr',
                                "scrollX": true,
                                "autoWidth": false,
                                "language": {
                                    "emptyTable": "No se encontraron registros con los filtros solicitados",
                                    "processing": "Cargando..."
                                },
                                "initComplete": function() {
                                    this.api().columns().every(function() {
                                        var that = this;
                                        $('input', this.header()).on('keyup change', function() {
                                            if (that.search() !== this.value) {
                                                that.search(this.value).draw();
                                            }
                                        });
                                    });
                                    new ClipboardJS('.btn-copy', {
                                        text: function(trigger) {
                                            var rowData = table.row($(trigger).closest('tr')).data();
                                            return `Cuenta: ${rowData.cuenta}, Nro Cuenta: ${rowData.nro_cuenta}, Codigo Unico: ${rowData.cod_unico}, Nro Documento: ${rowData.nrodocumento}, Saldo Disponible: ${rowData.sdo_disponible}, Saldo Contable: ${rowData.sdo_contable}, Fecha Apertura: ${rowData.fecha_apertura}, Nombre: ${rowData.nombre}`;
                                        }
                                    });
                                }
                            });
                        }

                        setSelectedValues();
                    },
                    error: function(xhr, status, error) {
                        console.error(error);
                        $('#loadingIndicator').hide();
                    }
                });
            });

            setSelectedValues();
        });
    </script>
</body>
</html>
