<?php
session_start();
require_once 'src/BusinessLogic/business_logic.php';

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

if (!isset($_SESSION['usuario'])) {
    header('Location: index.php');
    exit;
}

$usuario_id = $_SESSION['usuario'];
$es_admin = isset($_SESSION['admin']) && $_SESSION['admin'];

$datas = get_filtered_data();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.css">
    <style>
        .custom-navbar {
            background-color: #4caf50;
        }
        .table-responsive {
            margin-top: 20px;
            width: 100%;
        }
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .custom-navbar .navbar-nav .nav-link {
            color: #fff !important;
        }
        table.dataTable {
            width: 100% !important;
            border-top: 2px solid #ddd;
        }
        table.dataTable th, table.dataTable td {
            white-space: nowrap;
            text-align: center;
            border: 1px solid #ddd;
        }
        .text-left {
            text-align: left !important;
        }
        .btn-circle {
            border-radius: 50%;
            width: 35px;
            height: 35px;
            padding: 6px;
            background-color: #28a745;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            border: none;
            margin: 0 auto;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top custom-navbar">
        <a class="navbar-brand text-white fw-bold" style="margin-left: 15px;">DATA EN UAT</a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="data.php">DATA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="automatizaciones.php">AUTOMATIZACIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="solicitudes.php">SOLICITUDES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="regresiones.php">REGRESIONES</a>
                </li>
                <?php if ($es_admin): ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="mantenimiento.php">MANTENIMIENTO</a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" style="font-weight: bold;" href="logout.php">LOGOUT</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid mt-5 pt-4">
        <div id="table-container" class="table-responsive">
            <table id="tabla" class="table table-striped table-bordered nowrap" style="width:100%">
                <thead>
                    <tr>
                        <th>N°</th>
                        <th>DESCRIPCIÓN</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($datas as $data): ?>
                    <tr>
                        <td><?php echo sanitize_input($data['ID']); ?></td>
                        <td class="text-left"><?php echo sanitize_input($data['DESCRIPCION']); ?></td>
                        <td class="text-center">
                            <a href="<?php echo sanitize_input($data['PAGINA']); ?>" class="btn-circle btn-primary"><i class="bi bi-arrow-right"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#tabla').DataTable({
                responsive: true,
                searching: false,
                lengthChange: false,
                paging: false,
                ordering: false,
                dom: 't'
            });
        });
    </script>
</body>
</html>
