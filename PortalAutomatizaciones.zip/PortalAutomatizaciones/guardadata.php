<?php
// Datos de conexión a la base de datos
$host = 'localhost';
$dbname = 'portalautomatizaciones';
$user = 'root';
$pass = '';

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Verificar si los datos se recibieron correctamente
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id_automatizacion = $_POST['id_automatizacion'];
        $parametros_entrada = $_POST['parametros_entrada'];
        $estado = $_POST['estado'];
        $id_usuario = $_POST['usuario'];

        // Validar que no estén vacíos
        if (empty($id_automatizacion) || empty($parametros_entrada) || empty($estado) || empty($id_usuario)) {
            echo json_encode(['status' => 'error', 'message' => 'Todos los campos son obligatorios']);
            exit;
        }

        // Preparar la consulta SQL
        $stmt = $pdo->prepare("INSERT INTO solicitudes (id_automatizacion, parametros_entrada, estado, idusuario) VALUES (:id_automatizacion, :parametros_entrada, :estado, :usuario)");
        $stmt->bindParam(':id_automatizacion', $id_automatizacion);
        $stmt->bindParam(':parametros_entrada', $parametros_entrada);
        $stmt->bindParam(':estado', $estado);
        $stmt->bindParam(':usuario', $id_usuario);

        // Ejecutar la consulta
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Datos guardados correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error al guardar los datos']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Método de solicitud no válido']);
    }
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error de conexión: ' . $e->getMessage()]);
}
?>
