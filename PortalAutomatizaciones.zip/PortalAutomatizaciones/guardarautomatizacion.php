<?php
require_once '../src/DataAccess/db_connection.php';

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equipo_id = sanitize_input($_POST['equipo_id']);
    $funcionalidad = sanitize_input($_POST['funcionalidad']);
    $aplicativo_id = sanitize_input($_POST['aplicativo_id']);
    $tecnologia_id = sanitize_input($_POST['tecnologia_id']);
    $entorno_id = sanitize_input($_POST['entorno_id']);
    $bitbucket_url = sanitize_input($_POST['bitbucket_url']);
    $carpetaarchivodata = sanitize_input($_POST['carpetaarchivodata']);
    $nombrearchivodata = sanitize_input($_POST['nombrearchivodata']);
    $parametros_entrada = json_decode($_POST['parametros_entrada'], true);

    // Abrir la conexión a la base de datos
    $pdo = openConnection();

    try {
        // Iniciar transacción
        $pdo->beginTransaction();

        // Insertar la automatización
        $sql_automatizacion = "INSERT INTO automatizaciones (equipo_id, funcionalidad, aplicativo_id, tecnologia_id, entorno_id, bitbucket_url, carpeta, archivo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_automatizacion = $pdo->prepare($sql_automatizacion);
        $stmt_automatizacion->execute([$equipo_id, $funcionalidad, $aplicativo_id, $tecnologia_id, $entorno_id, $bitbucket_url, $carpetaarchivodata, $nombrearchivodata]);

        $automatizacion_id = $pdo->lastInsertId();

        // Insertar los parámetros de entrada
        $sql_parametros = "INSERT INTO parametrosentrada (automatizacion_id, nombre_parametro, flag_id) VALUES (?, ?, '1')";
        $stmt_parametros = $pdo->prepare($sql_parametros);

        foreach ($parametros_entrada as $parametro) {
            $stmt_parametros->execute([$automatizacion_id, $parametro]);
        }

        // Confirmar transacción
        $pdo->commit();
    } catch (Exception $e) {
        // En caso de error, revertir transacción
        $pdo->rollBack();
        throw $e;
    }

    // Cerrar la conexión a la base de datos
    closeConnection($pdo);

    // Redirigir a automatizaciones.php
    header('Location: automatizaciones.php');
    exit();
}
?>
