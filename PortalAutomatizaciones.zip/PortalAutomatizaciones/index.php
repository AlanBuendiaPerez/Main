<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de Automatizaciones</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">
    <style>
        body, html {
            height: 100%;
            width: 100%;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f2f2f2;
        }
        .login-container {
            width: 100%;
            height: 100%;
            display: flex;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .login-image {
            flex: 2;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #fff;
        }
        .login-image img {
            max-width: 100%;
            height: auto;
        }
        .login-form {
            flex: 1;
            padding: 40px;
            background-color: #fff;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .login-form h5 {
            text-align: center;
            margin-bottom: 30px;
            color: #4caf50;
            font-weight: bold;
            font-size: 24px;
        }
        .btn-custom {
            background-color: #4caf50;
            width: 100%;
            color: white;
        }
        .btn-custom:hover {
            background-color: #43a047;
        }
        .select2-container--default .select2-selection--single {
            height: 38px;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 36px;
            padding-left: 10px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }
        .form-group {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
<div class="login-container">
    <div class="login-image">
        <img src="assets/images/login_ilustracion.jpg" alt="Logo">
    </div>
    <div class="login-form">
        <h5>PORTAL DE AUTOMATIZACIONES</h5>
        <form id="loginForm" action="login.php" method="POST">
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" id="isAdmin" name="isAdmin">
                <label class="form-check-label" for="isAdmin">Administrador</label>
            </div>
            <div class="form-group">
                <select class="form-control select2" id="usuario" name="usuario" required>
                    <option value="" disabled selected>Seleccione un usuario</option>
                    <?php
                    require_once __DIR__ . '/src/BusinessLogic/business_logic.php';
                    echo getOptions('usuarios');
                    ?>
                </select>
            </div>
            <div class="form-group" id="adminCodeGroup" style="display: none;">
                <input type="text" class="form-control" id="adminCode" name="adminCode" placeholder="Ingrese el código de administrador">
            </div>
            <button class="btn btn-custom" type="submit" name="action">Iniciar Sesión</button>
        </form>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: 'Seleccione un usuario',
            allowClear: true
        });

        $('#isAdmin').on('change', function() {
            if ($(this).is(':checked')) {
                $('#adminCodeGroup').show();
                $('#adminCode').attr('required', 'required');
            } else {
                $('#adminCodeGroup').hide();
                $('#adminCode').removeAttr('required');
            }
        });

        $('#loginForm').on('submit', function(e) {
            if ($('#isAdmin').is(':checked') && $('#adminCode').val() === '') {
                e.preventDefault();
                alert('Por favor, ingrese el código de administrador.');
            }
        });
    });
</script>
</body>
</html>
