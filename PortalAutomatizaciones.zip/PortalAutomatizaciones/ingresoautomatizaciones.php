<?php
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json');
}

require_once '../src/BusinessLogic/business_logic.php';

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

$equipos_options = getOptions('equipos');
$tecnologias_options = getOptions('tecnologias');
$aplicativos_options = getOptions('aplicativos');
$entornos_options = getOptions('entornos');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <style>
        .custom-navbar {
            background-color: #4caf50;
        }
        .form-container {
            margin-bottom: 20px;
        }
        .btn-submit, .btn-primary {
            background-color: #4caf50;
            color: #fff;
            border: 2px solid #45a049;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }
        .btn-submit:hover, .btn-primary:hover {
            background-color: #45a049;
            border-color: #5cb85c;
        }
        .btn-submit:active, .btn-primary:active {
            background-color: #5cb85c;
            border-color: #4caf50;
        }
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .custom-navbar .navbar-nav .nav-link {
            color: #fff !important;
        }
        .dataTable {
            border-top: 2px solid #ddd;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top custom-navbar">
        <a class="navbar-brand text-white fw-bold" style="margin-left: 15px;">INGRESO DE AUTOMATIZACIONES</a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle font-weight-bold" id="navbarDropdownCuentas" role="button" data-bs-toggle="dropdown" aria-expanded="false">CUENTAS</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownCuentas">
                        <li><a class="dropdown-item" href="cuentasahorro.php">Ahorros</a></li>
                        <li><a class="dropdown-item" href="cuentascorriente.php">Corrientes</a></li>
                        <li><a class="dropdown-item" href="cuentascts.php">CTS</a></li>
                        <li><a class="dropdown-item" href="cuentasplazo.php">Depositos a Plazos</a></li>
                        <li><a class="dropdown-item" href="cuentascbn.php">CBN</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle font-weight-bold" id="navbarDropdownAutomatizaciones" role="button" data-bs-toggle="dropdown" aria-expanded="false">AUTOMATIZACIONES</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownAutomatizaciones">
                        <li><a class="dropdown-item" href="crearcuenta.php">Crear Cuentas</a></li>
                        <li><a class="dropdown-item" href="crearclientes.php">Crear Clientes</a></li>
                        <li><a class="dropdown-item" href="abonos.php">Abonos</a></li>
                        <li><a class="dropdown-item" href="retiros.php">Retiros</a></li>
                        <li><a class="dropdown-item" href="movimientos.php">Movimientos</a></li>
                        <li><a class="dropdown-item" href="consultacuentas.php">Consulta de Cuentas</a></li>
                        <li><a class="dropdown-item" href="cambioestados.php">Cambios de Estados</a></li>
                        <li><a class="dropdown-item" href="cancelacioncuenta.php">Cancelación de Cuenta</a></li>
                        <li><a class="dropdown-item" href="pacman.php">Pacman</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="peticiones.php">PETICIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="regresiones.php">REGRESIONES</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle font-weight-bold" id="navbarDropdownBaseConocimiento" role="button" data-bs-toggle="dropdown" aria-expanded="false">BASE DE CONOCIMIENTO</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownBaseConocimiento">
                        <li><a class="dropdown-item" href="cargarinformacion.php">Cargar Información</a></li>
                        <li><a class="dropdown-item" href="consultas.php">Consultas</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container-fluid mt-5 pt-4">
        <div class="row">
            <div class="col-md-12">
                <form method="POST" action="guardarautomatizacion.php" class="form-container" id="mainForm">
                    <div class="row mb-3">
                        <div class="col-md-2">
                            <label for="equipo_id" style="font-weight: bold;">Equipo</label>
                            <select id="equipo_id" name="equipo_id" class="form-control">
                                <option value="" disabled selected>Seleccione un equipo</option>
                                <?php echo $equipos_options; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="funcionalidad" style="font-weight: bold;">Funcionalidad</label>
                            <input type="text" id="funcionalidad" name="funcionalidad" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label for="aplicativo_id" style="font-weight: bold;">Aplicativo IBK</label>
                            <select id="aplicativo_id" name="aplicativo_id" class="form-control">
                                <option value="" disabled selected>Seleccione un aplicativo</option>
                                <?php echo $aplicativos_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="tecnologia_id" style="font-weight: bold;">Tipo de Tecnología</label>
                            <select id="tecnologia_id" name="tecnologia_id" class="form-control">
                                <option value="" disabled selected>Seleccione una tecnología</option>
                                <?php echo $tecnologias_options; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label for="entorno_id" style="font-weight: bold;">Entorno de Desarrollo</label>
                            <select id="entorno_id" name="entorno_id" class="form-control">
                                <option value="" disabled selected>Seleccione un entorno</option>
                                <?php echo $entornos_options; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">
                            <label for="bitbucket_url" style="font-weight: bold;">Bitbucket URL</label>
                            <input type="url" id="bitbucket_url" name="bitbucket_url" class="form-control" placeholder="Ingresa la ruta">
                        </div>
                        <div class="col-md-2">
                            <label for="carpetaarchivodata" style="font-weight: bold;">Carpeta del archivo de data</label>
                            <input type="text" class="form-control" id="carpetaarchivodata" name="carpetaarchivodata" placeholder="Ingrese carpeta">
                        </div>
                        <div class="col-md-2">
                            <label for="nombrearchivodata" style="font-weight: bold;">Nombre Archivo Data .xlsx</label>
                            <input type="text" class="form-control" id="nombrearchivodata" name="nombrearchivodata" placeholder="Ingrese nombre del archivo">
                        </div>
                        <div class="col-md-2">
                            <label for="dynamicInputText" style="font-weight: bold;">Parámetros de Entrada</label>
                            <input type="text" class="form-control" id="dynamicInputText" placeholder="Ingrese parámetros">
                        </div>
                        <div class="col-md-1 d-flex align-items-end">
                            <button type="button" class="btn btn-primary w-100" id="addButton">Agregar</button>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table id="dynamicTable" class="table table-striped table-bordered nowrap" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Nombre del Parámetro de Entrada</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="dynamicItemList">
                            </tbody>
                        </table>
                    </div>

                    <div class="row mt-3">
                        <div class="col-md-12 d-flex justify-content-end">
                        <button type="submit" class="btn btn-submit" id="submitButton" disabled>INGRESAR AUTOMATIZACION</button>
                        </div>
                    </div>
                    <input type="hidden" name="parametros_entrada" id="parametros_entrada">
                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            var table = $('#dynamicTable').DataTable({
                responsive: true,
                searching: false,
                lengthChange: false,
                paging: false
            });

            function checkFormValidity() {
                var isValid = $('#equipo_id').val() &&
                              $('#funcionalidad').val() &&
                              $('#aplicativo_id').val() &&
                              $('#tecnologia_id').val() &&
                              $('#entorno_id').val() &&
                              $('#bitbucket_url').val() &&
                              $('#carpetaarchivodata').val() &&
                              $('#nombrearchivodata').val() &&
                              table.data().count() > 0;

                $('#submitButton').prop('disabled', !isValid);
            }

            $('#equipo_id, #funcionalidad, #aplicativo_id, #tecnologia_id, #entorno_id, #bitbucket_url, #carpetaarchivodata, #nombrearchivodata').on('change keyup', checkFormValidity);

            $('#addButton').click(function() {
                var dynamicInputText = $('#dynamicInputText').val();
                var isDuplicate = false;

                table.rows().every(function() {
                    var data = this.data();
                    if (data[0] === dynamicInputText) {
                        isDuplicate = true;
                        return false;
                    }
                });

                if (isDuplicate) {
                    alert('El parámetro ya existe en la tabla.');
                } else if (dynamicInputText) {
                    table.row.add([
                        dynamicInputText,
                        '<button class="btn btn-danger btn-sm delete-button">Eliminar</button>'
                    ]).draw(false);

                    $('#dynamicInputText').val('');
                    checkFormValidity();
                } else {
                    alert('Por favor, ingrese un texto.');
                }
            });

            $('#dynamicTable tbody').on('click', '.delete-button', function() {
                table.row($(this).parents('tr')).remove().draw();
                checkFormValidity();
            });

            $('#mainForm').on('submit', function(e) {
                var parametrosEntrada = [];
                table.rows().every(function() {
                    parametrosEntrada.push(this.data()[0]);
                });

                $('#parametros_entrada').val(JSON.stringify(parametrosEntrada));
            });

            checkFormValidity();
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>