<?php
session_start();
require_once __DIR__ . '/src/BusinessLogic/business_logic.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioId = $_POST['usuario'];
    $isAdmin = isset($_POST['isAdmin']) ? true : false;
    $adminCode = isset($_POST['adminCode']) ? $_POST['adminCode'] : '';

    if ($isAdmin && !empty($adminCode)) {
        $isAdminValid = validateAdminCredentials($usuarioId, $adminCode);
        if ($isAdminValid) {
            $_SESSION['usuario'] = $usuarioId;
            $_SESSION['admin'] = true;
            header('Location: data.php'); // Redirige a data.php en lugar de base_datos.php
        } else {
            echo 'Clave de administrador incorrecta.';
        }
    } else {
        $_SESSION['usuario'] = $usuarioId;
        $_SESSION['admin'] = false;
        header('Location: data.php');
    }
    exit;
} else {
    echo 'Método no permitido.';
}
?>
