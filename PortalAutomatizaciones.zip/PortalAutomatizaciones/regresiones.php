<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <!-- Incluir Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Incluir DataTables CSS -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
    <style>
        #data-table-container {
            display: none; /* Ocultar la tabla al cargar la página */
        }
    </style>
</head>
<body>
    <!-- Barra de navegación fija en la parte superior -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <a class="navbar-brand" href="#">REGRESIONES</a>
        <!-- Botón del menú de hamburguesa sin data-toggle -->
        <button class="navbar-toggler collapsed" type="button" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Opciones de navegación siempre visibles -->
        <div class="navbar-nav ml-auto">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="data.php">Data</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownAutomatizaciones" role="button" data-toggle="dropdown" aria-expanded="false">
                        Automatizaciones
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownAutomatizaciones">
                        <li><a class="dropdown-item" href="crearcuenta.php">Crear Cuentas</a></li>
                        <li><a class="dropdown-item" href="crearclientes.php">Crear Clientes</a></li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="peticiones.php">Peticiones</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="regresiones.php">Regresiones</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" id="navbarDropdownAutomatizaciones" role="button" data-toggle="dropdown" aria-expanded="false">
                        Base de Conocimiento
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdownAutomatizaciones">
                        <li><a class="dropdown-item" href="cargarinformacion.php">Cargar Informacion</a></li>
                        <li><a class="dropdown-item" href="consultas.php">Consultas</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    <!-- Contenedor principal para el contenido de las páginas -->
    <div class="container-fluid mt-5">
        <!-- Grilla con padres e hijos -->
        <div class="accordion" id="accordionExample">
            <br>
            <!-- Primer padre -->
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            FECHA: 2024/02/22
                        </button>
                    </h2>
                </div>

                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                    <div class="card-body">
                        <!-- Tabla de hijos -->
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Flujo</th>
                                    <th>Descripción</th>
                                    <th>Ejecuciones</th>
                                    <th>Éxito</th>
                                    <th>Fallido</th>
                                    <th>Estado</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Crear Cuenta</td>
                                    <td>Creacion de cuentas ahorros</td>
                                    <td>10</td>
                                    <td>10</td>
                                    <td>0</td>
                                    <td>Procesado</td>
                                    <td><button class="btn btn-primary ver-detalle-btn" data-url="pantallas.php">Ver Detalle</button></td>
                                </tr>
                                <tr>
                                    <td>Abono</td>
                                    <td>Realizan abonos en la cuenta de ahorro</td>
                                    <td>15</td>
                                    <td>15</td>
                                    <td>0</td>
                                    <td>Ejecucion</td>
                                    <td><button class="btn btn-primary ver-detalle-btn" data-url="pantallas.php">Ver Detalle</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Segundo padre -->
            <div class="card">
                <div class="card-header" id="headingTwo">
                    <h2 class="mb-0">
                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            FECHA: 2024/02/23
                        </button>
                    </h2>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                    <div class="card-body">
                        <!-- Tabla de hijos -->
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Flujo</th>
                                    <th>Descripción</th>
                                    <th>Ejecuciones</th>
                                    <th>Éxito</th>
                                    <th>Fallido</th>
                                    <th>Estado</th>
                                    <th>Detalle</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Flujo 3</td>
                                    <td>Descripción 3</td>
                                    <td>20</td>
                                    <td>18</td>
                                    <td>2</td>
                                    <td>Estado 3</td>
                                    <td><button class="btn btn-primary ver-detalle-btn" data-url="pantallas.php">Ver Detalle</button></td>
                                </tr>
                                <tr>
                                    <td>Flujo 4</td>
                                    <td>Descripción 4</td>
                                    <td>25</td>
                                    <td>20</td>
                                    <td>5</td>
                                    <td>Estado 4</td>
                                    <td><button class="btn btn-primary ver-detalle-btn" data-url="pantallas.php">Ver Detalle</button></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para mostrar el contenido de pantallas.php -->
    <div class="modal fade" id="modalPantallas" tabindex="-1" role="dialog" aria-labelledby="modalPantallasLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalPantallasLabel">Detalle de la regresión</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Contenido de la página pantallas.php se cargará aquí -->
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery y Bootstrap JavaScript -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
    <!-- Script para inicializar DataTables y manejar la apertura de la modal -->
    <script>
        $(document).ready(function() {
            $('#accordionExample .ver-detalle-btn').click(function() {
                var url = $(this).data('url');
                $('#modalPantallas .modal-body').load(url);
                $('#modalPantallas').modal('show');
            });
        });
    </script>
</body>
</html>
