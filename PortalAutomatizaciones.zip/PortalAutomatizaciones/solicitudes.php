<?php
require_once '../src/BusinessLogic/business_logic.php';

// Obtener datos de solicitudes
$solicitudes = get_filtered_solicitudes();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.css">
    <style>
        .custom-navbar {
            background-color: #4caf50;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .container-fluid {
            padding-left: 15px;
            padding-right: 15px;
        }
        .custom-navbar .navbar-nav .nav-link {
            color: #fff !important;
        }
        table.dataTable thead .column-filter {
            width: 100%;
            padding: 3px;
            box-sizing: border-box;
            border: 1px solid #ccc;
        }
        table.dataTable {
            border-top: 2px solid #ddd;
        }
        .text-center {
            text-align: center;
        }
        .btn-datos {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 6px 12px;
            margin: 0 auto;
            display: inline-block;
            font-size: 14px;
        }
        .btn-datos:hover {
            background-color: #218838;
            color: #fff;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg fixed-top custom-navbar">
        <a class="navbar-brand text-white fw-bold" style="margin-left: 15px;">SOLICITUDES</a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="data.php">DATA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="automatizaciones.php">AUTOMATIZACIONES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="solicitudes.php">SOLICITUDES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link font-weight-bold" href="regresiones.php">REGRESIONES</a>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container-fluid mt-5 pt-4">
        <div class="row">
            <div class="col-md-12">
                <div id="table-container" class="table-responsive">
                    <table id="tablaResultados" class="table table-striped table-bordered nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Funcionalidad</th>
                                <th>Estado</th>
                                <th>Fecha Creación</th>
                                <th class="text-center"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($solicitudes as $solicitud): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($solicitud['ID']); ?></td>
                                    <td><?php echo htmlspecialchars($solicitud['NOMBRE']); ?></td>
                                    <td><?php echo htmlspecialchars($solicitud['FUNCIONALIDAD']); ?></td>
                                    <td><?php echo htmlspecialchars($solicitud['ESTADO']); ?></td>
                                    <td><?php echo htmlspecialchars($solicitud['FECHA_CREACION']); ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-datos" data-parametros='<?php echo htmlspecialchars($solicitud['PARAMETROS_ENTRADA']); ?>'>Datos</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal para mostrar parámetros -->
    <div class="modal fade" id="parametrosModal" tabindex="-1" aria-labelledby="parametrosModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="parametrosModalLabel">Parámetros de Entrada</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="parametrosTabla"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            var table = $('#tablaResultados').DataTable({
                responsive: true,
                lengthChange: false,
                paging: false, // Desactiva el paginado
                ordering: false, // Desactiva el ordenamiento
                dom: 't'
            });

            $('.column-filter').on('keyup change', function() {
                var column = table.column($(this).data('column'));
                column.search(this.value).draw();
            });

            // Manejar el evento de clic en el botón "Datos"
            $('.btn-datos').on('click', function() {
                var parametros = $(this).attr('data-parametros');
                try {
                    parametros = JSON.parse(parametros);
                } catch (e) {
                    console.error('Error parsing JSON:', e);
                    return;
                }

                if (Array.isArray(parametros)) {
                    var html = '<table class="table table-bordered"><thead><tr>';
                    var keys = Object.keys(parametros[0]);
                    keys.forEach(function(key) {
                        html += '<th>' + key + '</th>';
                    });
                    html += '</tr></thead><tbody>';
                    parametros.forEach(function(item) {
                        html += '<tr>';
                        keys.forEach(function(key) {
                            html += '<td>' + item[key] + '</td>';
                        });
                        html += '</tr>';
                    });
                    html += '</tbody></table>';
                    $('#parametrosTabla').html(html);
                    $('#parametrosModal').modal('show');
                } else {
                    console.error('Expected array, got:', parametros);
                }
            });
        });
    </script>
</body>
</html>
