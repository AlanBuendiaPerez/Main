<?php
require_once __DIR__ . '/../DataAccess/data_access.php';

function getOptions($type) {
    switch ($type) {
        case 'usuarios':
            return buildOptions(get_all_usuarios(), 'id', 'nombre');
        case 'monedas':
            return buildOptions(get_all_monedas(), 'id', 'nombre');
        case 'productos':
            return buildOptions(get_all_productos(), 'id', 'descripcion');
        case 'documentos':
            return buildOptions(get_all_documentos(), 'id', 'descripcion');
        case 'restricciones_retiros':
            return buildOptions(get_all_restricciones_retiros(), 'id', 'id');
        case 'estados':
            return buildOptions(get_all_estados(), 'id', 'descripcion');
        case 'oficinas':
            return buildOptions(get_all_oficinas(), 'id', 'id');
        case 'equipos':
            return buildOptions(get_all_equipos(), 'id', 'nombre');
        case 'tecnologias':
            return buildOptions(get_all_tecnologias(), 'id', 'nombre');
        case 'aplicativos':
            return buildOptions(get_all_aplicativos(), 'id', 'nombre');
        case 'entornos':
            return buildOptions(get_all_entornos(), 'id', 'nombre');
    }
}

function buildOptions($data, $valueField, $textField) {
    $options = "";
    foreach ($data as $item) {
        $options .= "<option value='{$item[$valueField]}'>{$item[$textField]}</option>";
    }
    return $options;
}

function get_filtered_cuentasahorros($filters) {
    return filter_cuentasahorros([
        'moneda' => $filters['moneda'],
        'oficina' => $filters['oficina'],
        'estado' => $filters['estado'],
        'producto' => $filters['producto'],
        'tipodoc' => $filters['tipodoc'],
        'restriccion' => $filters['restriccion']
    ]);
}

function get_filtered_cuentascorrientes($filters) {
    return filter_cuentascorrientes([
        'moneda' => $filters['moneda'],
        'oficina' => $filters['oficina'],
        'estado' => $filters['estado'],
        'producto' => $filters['producto'],
        'tipodoc' => $filters['tipodoc'],
        'restriccion' => $filters['restriccion']
    ]);
}

function get_filtered_cuentascts($filters) {
    return filter_cuentascts([
        'moneda' => $filters['moneda'],
        'oficina' => $filters['oficina'],
        'estado' => $filters['estado'],
        'producto' => $filters['producto'],
        'tipodoc' => $filters['tipodoc'],
        'restriccion' => $filters['restriccion']
    ]);
}

function get_filtered_cuentasplazo($filters) {
    return filter_cuentasplazo([
        'moneda' => $filters['moneda'],
        'oficina' => $filters['oficina'],
        'estado' => $filters['estado'],
        'producto' => $filters['producto'],
        'tipodoc' => $filters['tipodoc'],
        'restriccion' => $filters['restriccion']
    ]);
}

function get_filtered_cuentascbn($filters) {
    return filter_cuentascbn([
        'moneda' => $filters['moneda'],
        'oficina' => $filters['oficina'],
        'estado' => $filters['estado'],
        'producto' => $filters['producto'],
        'tipodoc' => $filters['tipodoc'],
        'restriccion' => $filters['restriccion']
    ]);
}


function get_filtered_parametrosentrada($filters) {
    return filter_parametrosentrada([
        'id_automatizacion' => $filters['id_automatizacion']
    ]);
}

function get_filtered_automatizaciones() {
    return get_automatizaciones();
}

function get_filtered_data() {
    return get_datas();
}


function get_filtered_solicitudes() {
    return get_solicitudes();
}

function validateAdminCredentials($id, $clave) {
    return validateAdmin($id, $clave);
}