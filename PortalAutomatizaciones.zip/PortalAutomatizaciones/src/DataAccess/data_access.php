<?php
require_once 'db_connection.php';

function get_all_usuarios() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, nombre FROM usuarios");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_monedas() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, CONCAT(nombre, ' - ', id) AS nombre FROM monedas");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_productos() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, CONCAT(descripcion, ' - ', id) AS descripcion FROM productos");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_documentos() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, CONCAT(descripcion, ' - ', id) AS descripcion FROM tiposdocumentos");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_oficinas() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, id FROM oficinas");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_categorias() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, CONCAT(descripcion, ' - ', id) AS descripcion FROM categorias");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_restricciones_retiros() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, id FROM restriccionesretiros");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_estados() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, CONCAT(descripcion, ' - ', id) AS descripcion FROM estados");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_tipospersonas() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, descripcion FROM tipospersonas");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}


function get_all_equipos() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, nombre FROM equipos");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}


function get_all_tecnologias() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, nombre FROM tecnologias");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_aplicativos() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, nombre FROM aplicativos");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_all_entornos() {
    $pdo = openConnection();
    $statement = $pdo->query("SELECT id, nombre FROM entornos");
    $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function filter_cuentasahorros($filters) {
    $pdo = openConnection();
    try {
        $sql = "SELECT * FROM cuentasahorros WHERE moneda_id = :moneda AND oficina_id = :oficina AND estado_id = :estado AND producto_id = :producto AND tipodocumento_id = :tipodoc AND restriccion_retiro_id = :restriccion";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(":moneda", $filters['moneda']);
        $statement->bindValue(":oficina", $filters['oficina']);
        $statement->bindValue(":estado", $filters['estado']);
        $statement->bindValue(":producto", $filters['producto']);
        $statement->bindValue(":tipodoc", $filters['tipodoc']);
        $statement->bindValue(":restriccion", $filters['restriccion']);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        closeConnection($pdo);
        return $results;
    } catch (PDOException $e) {
        error_log($e->getMessage());
        closeConnection($pdo);
        return []; // Retornar un arreglo vacío en caso de error
    }
}

function filter_cuentascorrientes($filters) {
    $pdo = openConnection();
    try {
        $sql = "SELECT * FROM cuentascorrientes WHERE moneda_id = :moneda AND oficina_id = :oficina AND estado_id = :estado AND producto_id = :producto AND tipodocumento_id = :tipodoc AND restriccion_retiro_id = :restriccion";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(":moneda", $filters['moneda']);
        $statement->bindValue(":oficina", $filters['oficina']);
        $statement->bindValue(":estado", $filters['estado']);
        $statement->bindValue(":producto", $filters['producto']);
        $statement->bindValue(":tipodoc", $filters['tipodoc']);
        $statement->bindValue(":restriccion", $filters['restriccion']);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        closeConnection($pdo);
        return $results;
    } catch (PDOException $e) {
        error_log($e->getMessage());
        closeConnection($pdo);
        return []; // Retornar un arreglo vacío en caso de error
    }
}

function filter_cuentascts($filters) {
    $pdo = openConnection();
    try {
        $sql = "SELECT * FROM cuentascts WHERE moneda_id = :moneda AND oficina_id = :oficina AND estado_id = :estado AND producto_id = :producto AND tipodocumento_id = :tipodoc AND restriccion_retiro_id = :restriccion";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(":moneda", $filters['moneda']);
        $statement->bindValue(":oficina", $filters['oficina']);
        $statement->bindValue(":estado", $filters['estado']);
        $statement->bindValue(":producto", $filters['producto']);
        $statement->bindValue(":tipodoc", $filters['tipodoc']);
        $statement->bindValue(":restriccion", $filters['restriccion']);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        closeConnection($pdo);
        return $results;
    } catch (PDOException $e) {
        error_log($e->getMessage());
        closeConnection($pdo);
        return []; // Retornar un arreglo vacío en caso de error
    }
}

function filter_cuentasplazo($filters) {
    $pdo = openConnection();
    try {
        $sql = "SELECT * FROM cuentasplazos WHERE moneda_id = :moneda AND oficina_id = :oficina AND estado_id = :estado AND producto_id = :producto AND tipodocumento_id = :tipodoc AND restriccion_retiro_id = :restriccion";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(":moneda", $filters['moneda']);
        $statement->bindValue(":oficina", $filters['oficina']);
        $statement->bindValue(":estado", $filters['estado']);
        $statement->bindValue(":producto", $filters['producto']);
        $statement->bindValue(":tipodoc", $filters['tipodoc']);
        $statement->bindValue(":restriccion", $filters['restriccion']);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        closeConnection($pdo);
        return $results;
    } catch (PDOException $e) {
        error_log($e->getMessage());
        closeConnection($pdo);
        return []; // Retornar un arreglo vacío en caso de error
    }
}

function filter_cuentascbn($filters) {
    $pdo = openConnection();
    try {
        $sql = "SELECT * FROM cuentascbn WHERE moneda_id = :moneda AND oficina_id = :oficina AND estado_id = :estado AND producto_id = :producto AND tipodocumento_id = :tipodoc AND restriccion_retiro_id = :restriccion";
        $statement = $pdo->prepare($sql);
        $statement->bindValue(":moneda", $filters['moneda']);
        $statement->bindValue(":oficina", $filters['oficina']);
        $statement->bindValue(":estado", $filters['estado']);
        $statement->bindValue(":producto", $filters['producto']);
        $statement->bindValue(":tipodoc", $filters['tipodoc']);
        $statement->bindValue(":restriccion", $filters['restriccion']);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
        $statement->closeCursor();
        closeConnection($pdo);
        return $results;
    } catch (PDOException $e) {
        error_log($e->getMessage());
        closeConnection($pdo);
        return []; // Retornar un arreglo vacío en caso de error
    }
}


function get_automatizaciones() {
    $pdo = openConnection();
    try {
        $sql = "SELECT E.NOMBRE as EQUIPO, A.FUNCIONALIDAD AS FUNCIONALIDAD, AP.NOMBRE AS APLICATIVO , T.NOMBRE AS TECNOLOGIA ,
        EN.NOMBRE AS ENTORNO, A.ID AS ID
        FROM AUTOMATIZACIONES A 
        INNER JOIN EQUIPOS E ON A.EQUIPO_ID = E.ID
        INNER JOIN APLICATIVOS AP ON A.APLICATIVO_ID = AP.ID
        INNER JOIN TECNOLOGIAS T ON A.TECNOLOGIA_ID = T.ID
        INNER JOIN ENTORNOS EN ON A.ENTORNO_ID = EN.ID";
        $statement = $pdo->prepare($sql);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $results = []; // Retornar un arreglo vacío en caso de error
    }
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function filter_parametrosentrada($filters) {
    $pdo = openConnection();
    try {
        // Verificar si el índice 'tipopersona' está presente en el array $filters
        if (isset($filters['id_automatizacion'])) {
            $sql = "SELECT NOMBRE_PARAMETRO FROM PARAMETROSENTRADA WHERE AUTOMATIZACION_ID = :id_automatizacion";
            $statement = $pdo->prepare($sql);
            $statement->bindValue(":id_automatizacion", $filters['id_automatizacion']);
            $statement->execute();
            $results = $statement->fetchAll(PDO::FETCH_ASSOC);
            $statement->closeCursor();
            closeConnection($pdo);
            return $results;
        } else {
            // Si 'tipopersona' no está presente, retornar un arreglo vacío
            return [];
        }
    } catch (PDOException $e) {
        error_log($e->getMessage());
        closeConnection($pdo);
        return []; // Retornar un arreglo vacío en caso de error
    }
}



function get_datas() {
    $pdo = openConnection();
    try {
        $sql = "SELECT ID , DESCRIPCION, PAGINA
        FROM DATAS";
        $statement = $pdo->prepare($sql);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $results = []; // Retornar un arreglo vacío en caso de error
    }
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function get_solicitudes() {
    $pdo = openConnection();
    try {
        $sql = "SELECT S.ID, S.ID_AUTOMATIZACION, U.NOMBRE, A.FUNCIONALIDAD, SE.ESTADO, S.PARAMETROS_ENTRADA, S.FECHA_CREACION 
                FROM SOLICITUDES S 
                INNER JOIN AUTOMATIZACIONES A ON S.ID_AUTOMATIZACION = A.ID
                INNER JOIN USUARIOS U ON S.IDUSUARIO = U.ID
                INNER JOIN SOLICITUDESESTADOS SE ON S.ESTADO = SE.ID
                ORDER BY S.FECHA_CREACION DESC";
        $statement = $pdo->prepare($sql);
        $statement->execute();
        $results = $statement->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $results = []; // Retornar un arreglo vacío en caso de error
    }
    $statement->closeCursor();
    closeConnection($pdo);
    return $results;
}

function validateAdmin($id, $clave) {
    $pdo = openConnection();
    try {
        $sql = "SELECT * FROM USUARIOS WHERE id = :id AND clave = :clave";
        $statement = $pdo->prepare($sql);
        $statement->bindParam(':id', $id, PDO::PARAM_INT);
        $statement->bindParam(':clave', $clave, PDO::PARAM_STR);
        $statement->execute();
        $result = $statement->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $result = false; // Retornar falso en caso de error
    }
    $statement->closeCursor();
    closeConnection($pdo);
    return $result ? true : false; // Retornar true si se encuentra un resultado, false si no
}


