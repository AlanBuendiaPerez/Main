<?php
require_once __DIR__ . '/../../config/config.php';

function openConnection() {
    global $host, $db_name, $user, $password;
    
    try {
        $pdo = new PDO("mysql:host=$host;dbname=$db_name", $user, $password);
        // Configuraciones adicionales de PDO, si son necesarias
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Error en la conexión a la base de datos: " . $e->getMessage());
    }
}

function closeConnection(&$pdo) {
    $pdo = null;
}
?>
