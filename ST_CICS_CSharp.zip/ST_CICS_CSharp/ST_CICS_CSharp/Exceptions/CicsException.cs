﻿using Base.Utils;
using System;

namespace Base.Exceptions
{
    internal class CicsException
    {
        public static void DetenerEInformar(string mensaje)
        {
            Utilidad.CapturarEvidenciaCics();

            Utilidad.RegistrarLog(mensaje);
            throw new Exception(mensaje);
        }
    }
}
