﻿using Base.Utils;

namespace Base.Interactions
{
    class Escribir
    {
        public static void Texto(string texto)
        {
            Global.terminal.SetText(texto);
        }
    }
}
