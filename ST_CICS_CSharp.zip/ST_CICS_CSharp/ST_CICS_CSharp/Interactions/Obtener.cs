﻿using Base.Utils;
using System;


namespace Base.Interactions
{
    class Obtener
    {
        public static string Texto(Enum y, Enum x, Enum longitud)
        {
            string texto = Global.terminal.GetText(Convert.ToInt32(x) - 1, Convert.ToInt32(y) - 1, Convert.ToInt32(longitud));
            return texto;
        }
    }
}
