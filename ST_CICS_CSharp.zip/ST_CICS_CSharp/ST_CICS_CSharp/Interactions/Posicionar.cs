﻿using Base.Utils;
using System;

namespace Base.Interactions
{
    class Posicionar
    {
        public static void Cursor(Enum y, Enum x)
        {
            Global.terminal.SetCursor(Convert.ToInt32(x) - 1, Convert.ToInt32(y) - 1);
        }

        internal static void Cursor(object posicion_Y, object posicion_X)
        {
            throw new NotImplementedException();
        }
    }
}
