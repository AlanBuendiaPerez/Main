﻿using Open3270;
using Base.Utils;

namespace Base.Interactions
{
    class Presionar
    {
        public static void Tecla(TnKey tecla)
        {
            Global.terminal.SendKey(true, tecla, Global.tiempo);
        }
    }
}
