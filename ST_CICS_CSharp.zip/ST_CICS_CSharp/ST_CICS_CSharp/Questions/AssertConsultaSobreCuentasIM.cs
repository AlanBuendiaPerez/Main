﻿using Base.Interactions;
using Base.Utils;
using NUnit.Framework;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Questions
{
    class AssertConsultaSobreCuentasIM
    {
        public static void ConsultarCuenta(string codigoUnicoEsperado)
        {
            //para obtener el codigo unico

            //string codigoUnicoObtenido = Obtener.Texto(OpcionConsultaSobreCuentasIMUI.ObtenerCodigoUnico.Posicion_Y, OpcionConsultaSobreCuentasIMUI.ObtenerCodigoUnico.Posicion_X, OpcionConsultaSobreCuentasIMUI.ObtenerCodigoUnico.Longitud);
            //Assert.AreEqual(codigoUnicoEsperado, codigoUnicoObtenido, "El código único de la cuenta creada no coincide con las esperada");
        }
    }
}
