﻿using Base.Interactions;
using Base.Utils;
using NUnit.Framework;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Questions
{
    class AssertInformacionCuentas
    {
        public static void ConsultarCuenta(string codigoUnicoEsperado)
        {
            //para obtener el codigo unico

            //string codigoUnicoObtenido = Obtener.Texto(OpcionInformacionCuentasUI.ObtenerCodigoUnico.Posicion_Y, OpcionInformacionCuentasUI.ObtenerCodigoUnico.Posicion_X, OpcionInformacionCuentasUI.ObtenerCodigoUnico.Longitud);
            //Assert.AreEqual(codigoUnicoEsperado, codigoUnicoObtenido, "El código único de la cuenta creada no coincide con las esperada");
        }
    }
}
