﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using Base.Utils;
using System;
using System.Globalization;
using System.IO;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace Base.Runner
{
    [Binding]
    class RunnerTest
    {
        [BeforeTestRun(Order = 0)]
        public static void BeforeTestRunDirectorio()
        {
            Global.fechaHoraIso8601 = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);


            SettingsJson.AsignarSettings();
            Global.rutaGeneral = Utilidad.RutaProyecto() + @"Resultados\" + DateTime.Now.ToString("yyyyMMdd") + @"\";

            if (Directory.Exists(Global.rutaGeneral))
            {
                DriveInfo di = new(Global.rutaGeneral);
                DirectoryInfo dirInfo = di.RootDirectory;
                DirectoryInfo[] dirInfos = dirInfo.GetDirectories("*.*");

                string[] registros = Directory.GetDirectories(Global.rutaGeneral);

                if (registros.Length > 0)
                {
                    int registroCapturado = 0;

                    foreach (var registro in registros)
                    {
                        registroCapturado = Convert.ToInt32(registro[(registro.LastIndexOf(@"\") + 1)..]);
                        Global.numeroEjecucion = registroCapturado;
                    }
                }
            }

            string nroEjecucion = "000" + (Global.numeroEjecucion + 1);
            Global.rutaResultados = Global.rutaGeneral + nroEjecucion[^3..] + @"\";
            Utilidad.CrearCarpeta(Global.rutaResultados);
        }
        [BeforeTestRun(Order = 1)]
        public static void BeforeTestRunPDF()
        {

            Document documento = null;
            Global.numSalto = 0;
            PdfWriter writer = null;

            Utilidad.CrearCarpeta($@"{Global.rutaResultados}Evidencias\\pdf\\");

            Global.nombreClase = Utilidad.NombreClase(typeof(RunnerTest));
            Global.tiempoDriveInicial = Utilidad.GetNanoseconds();
            try
            {
                documento = new Document(PageSize.Letter);
                writer = PdfWriter.GetInstance(documento, new FileStream((Global.rutaResultados + "Evidencias\\pdf\\" + DateTime.Now.Day + DateTime.Now.Month + DateTime.Now.Year + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + ".pdf"), FileMode.Create));//ruta donde se guarda el PDF

                documento.Open();
                documento.SetMargins(60, 20, 55, 20);
                Global.documento = documento;

                Paragraph parrafo = new Paragraph();
                parrafo.Font = new Font(FontFactory.GetFont("Arial", 12, BaseColor.Blue));
                parrafo.Alignment = Element.ALIGN_CENTER;
                Global.documento.Add(parrafo);
                parrafo.Add("REPORTE DE EVIDENCIAS AUTOMATIZADAS INTERBANK");// puede ir el nombre del SRT
                parrafo.Clear();

                BaseFont fuente = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, true);
                Font colorTitulo = new(fuente, 14f, Font.BOLD, new BaseColor(255, 0, 0));
                Global.documento.Add(new Paragraph("REPORTE IBK", colorTitulo));
                Global.numSalto++;

            }
            catch (Exception)
            {
                documento.Close();
                writer.Close();
            }
        }

        [BeforeScenario (Order = 4)]
        public static void BeforeScenario()
        {
            Utilidad.GenerarRutaEvidencias();
        }
        
        [BeforeScenario(Order = 5)]
        public static void BeforeTestRun()
        {
            Utilidad.Servidor();
        }

   
    }
}
