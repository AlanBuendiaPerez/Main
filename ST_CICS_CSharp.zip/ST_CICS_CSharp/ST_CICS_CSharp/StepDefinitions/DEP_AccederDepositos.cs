﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class DEP_AccederDepositos
    {
        [When(@"Accedo a Depositos del Cics Administrativo")]
        public static void AccedoADepositosDelCicsAdministrativo()
        {
            //Ingresar a Systematics
            CicsApp_SeleccionarSYS.AccesoOpcion("DEP");
            //Comprobar Menú Systematics
            DEP_DepositosAceder_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Menu de Depositos");
        }
    }
}
