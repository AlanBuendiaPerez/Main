﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class DEP_ConsultarMega
    {
        [Then(@"Consulto los MEGAS Pendientes de la Cuenta (.*), (.*), (.*), (.*)")]
        public static void ConsultoLosMEGASPendientesDeLaCuenta(string Moneda, string Oficina, string Categoria, string Cuenta)
        {
            //Ingresar a Comisiones Pendientes Mega
            DEP_ComisionesMega_Ingresar.Ingresar("04");
            //Comprobar Menú Systematics
            DEP_ComisionesMegaIngresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Comisiones Pendientes Mega");

            //Ingresar Cuenta
            DEP_ComisionesMega_Consultar.Consultar(Moneda, Oficina, Categoria, Cuenta);
            //Comprobrar Ingresar Cuenta
            DEP_ComisionesMegaConsultar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Comisiones Pendientes Mega");

            //Consultar Detalle de Cada Cuenta
            DEP_ComisionesMega_Detalle.Detalle();
            //Mensaje Final
            Utilidad.RegistrarLog("Se tomaron las evidencias correctamente");

        }
    }
}
