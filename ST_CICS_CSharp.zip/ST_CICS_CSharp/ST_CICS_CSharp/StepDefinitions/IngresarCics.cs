﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class IngresarCics
    {
        [Given(@"Accedo al Menu de Aplicativos")]

        public static void AccedoAlMenuDeAplicativos()
        {
            //Comprobar Conexión
            Conexion_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Conexion exitosa al servidor");

            //Ingresar Menú Access
            Access_Ingresar.Ingresar();
            //Comprobar Acceso a Menú Access
            AccessLogin_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Login Aplicaciones");

            //Ingresar Credenciales
            AccesLogin_Credenciales.Credenciales();
            //Comprobar Menú
            SeleccionApp_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla de Aplicaciones");

            //Limpiar Sesión en Menú de Apliaciones
            SeleccionarApp_Limpiar.Opcion("CICSAA2K");
            //Comprobar Limpiar Sesión
            SeleccionAppLimpiar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Sesion CICSAA2K limpiada");

            //Ingresar Opción 
            SeleccionarApp_Seleccionar.AccesoOpcion("CICSAA2K");
            //Comprobar Pantalla IB00
            IB00_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla IB00");

            //Ingresar IB00
            IB00_Ingresar.Ingresar();
            //Comprobar Igresar Credenciales
            LoginCics_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Login Cics Administrativo");

            //Ingresar Credenciales
            LoginCics_Ingresar.Credenciales();
            //Comprobar Aplicativos Cics
            CicsApp_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Cics Administrativo");
        }

        [Given(@"Accedo al Menu de Aplicativos dos")]

        public static void AccedoAlMenuDeAplicativosDos()
        {
            //Comprobar Conexión
            Conexion_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Conexion exitosa al servidor");

            //Ingresar Menú Access
            Access_Ingresar.Ingresar();
            //Comprobar Acceso a Menú Access
            AccessLogin_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Login Aplicaciones");

            //Ingresar Credenciales
            AccesLogin_Credenciales.Credenciales();
            //Comprobar Menú
            SeleccionApp_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla de Aplicaciones");

            //Limpiar Sesión en Menú de Apliaciones
            //SeleccionarApp_Limpiar.Opcion("CICSAA2K");
            //Comprobar Limpiar Sesión
            //SeleccionAppLimpiar_Comprobar.Pantalla();
            //Utilidad.RegistrarLog("Sesion CICSAA2K limpiada");

            //Ingresar Opción 
            SeleccionarApp_Seleccionar.AccesoOpcion("CICSAA2K");
            //Comprobar Pantalla IB00
            IB00_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla IB00");

            //Ingresar IB00
            //IB00_Ingresar.Ingresar();
            //Comprobar Igresar Credenciales
            LoginCics_Comprobar.Pantalla();
            //Utilidad.RegistrarLog("Accedio a pantalla Login Cics Administrativo");

            //Ingresar Credenciales
            //LoginCics_Ingresar.Credenciales();
            //Comprobar Aplicativos Cics
            CicsApp_Comprobar.Pantalla();
            //Utilidad.RegistrarLog("Accedio a pantalla Cics Administrativo");
        }
    }
}
