﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SSV_AccederAdministrativoSaving
    {
        [When(@"Accedo a Administrativo Saving del Cics Administrativo")]
        public static void AccedoaAdministrativoSavingdelCicsAdministrativo()
        {
            //Ingresar a Administrativo Saving
            CicsApp_SeleccionarSYS.AccesoOpcion("SSV");
            //Comprobar Administrativo Saving
            SSV_SavingAcceder_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Menu de Admiistrativo Saving");
        }
    }
}
