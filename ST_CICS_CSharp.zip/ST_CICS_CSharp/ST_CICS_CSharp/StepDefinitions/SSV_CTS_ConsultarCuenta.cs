﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SSV_CTS_ConsultarCuenta
    {
        [Then(@"Consulto la cuenta CTS con (.*), (.*), (.*), (.*)")]
        public static void ConsultolaCuentaCTSCon(string Moneda, string Oficina, string Cuenta, string Empleado)
        {
            //Ingresar opcion CTS o CTS Empleado
            SSV_AdicionalesCTSIngresar.Ingresar(Empleado);
            //Comprobar Acceso a Opcion Adicionales CTS
            SSV_AdicionalesCTSIngresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó a opcion Adicionales CTS");

            //Ingresa Datos Para Consulta CTS
            SSV_AdicionalesCTSConsultar.Consultar(Moneda, Oficina, Cuenta);
            //Comprobar Consulta CTS
            //SYS_STI1Consultar_Comprobar.Pantalla();
            //Utilidad.RegistrarLog("Se Consultó Cuenta en Comando STI1 de Systematics");

        }
    }
}
