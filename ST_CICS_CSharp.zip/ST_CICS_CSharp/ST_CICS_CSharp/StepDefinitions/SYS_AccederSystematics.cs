﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SYS_AccederSystematics
    {
        [Given(@"Accedo a Systematics del Cics Administrativo")]
        public static void AccedoASystematicsDelCicsAdministrativo()
        {
            //Ingresar a Systematics
            CicsApp_SeleccionarSYS.AccesoOpcion("SYS");
            //Comprobar Menú Systematics
            SystematicsAceder_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Accedio a pantalla Menu de Systematics");
        }

        [Given(@"Limpio la Pantalla de Systematics")]
        public static void LimpioLaPantallaDeSystematics()
        {
            //Limpiar Pantalla Systematics
            Systematics_Limpiar.Pantalla();
            //Comprobar Limpiar Pantalla
            SystematicsLimpiar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Limpio la pantalla Menu Systematics");
        }

        [When(@"Limpio la Pantalla de Systematics")]
        public static void LimpioLaPantallaDeSystematicsWhen()
        {
            //Limpiar Pantalla Systematics
            Systematics_Limpiar.Pantalla();
            //Comprobar Limpiar Pantalla
            SystematicsLimpiar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Limpio la pantalla Menu Systematics");
        }

        [Then(@"Limpio la Pantalla de Systematics")]
        public static void LimpioLaPantallaDeSystematicsThen()
        {
            //Limpiar Pantalla Systematics
            Systematics_Limpiar.Pantalla();
            //Comprobar Limpiar Pantalla
            SystematicsLimpiar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Limpio la pantalla Menu Systematics");
        }
    }
}
