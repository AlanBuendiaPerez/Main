﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SYS_RMAB_CrearCuenta
    {
        [Then(@"Ingreso a la Cuenta en Comando RMAB con (.*)")]
        public static void IngresoALaCuentaEnComandoSTI2Con(string Codigo_Unico)
        {
            //Ingresar a comando RMAB
            SYS_RMAB_Ingresar.Ingresar(Codigo_Unico);
            //Comprobar Ingreso a Comando RMAB
            SYS_RMABIngresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó a Comando RMSA de Systematics");
        }

        [Then(@"Ingreso a RMSA para crear la cuenta")]
        public static void IngresoARMSAParaCrearLaCuenta()
        {
            //Ingresar a comando RMSA
            SYS_RMSA_Ingresar.Ingresar();
            //Comprobar Ingreso a Comando RMSA
            SYS_RMSAIngresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó a Comando RMSA de Systematics");
        }

        [Then(@"Creo la Cuenta con (.*), (.*), (.*), (.*)")]
        public static void CreoLaCuentaCon(string Moneda, string Oficina, string Categoria, string Tipo_Producto)
        {
            //Ingresar Datos de la Centa a crear
            SYS_RMSA_IngresarDatos.Ingresar(Moneda, Oficina, Categoria, Tipo_Producto);
            //Comprobar el Ingreso de datos - cambia pantalla a st01 o imi01
            SYS_RMSAIngresarDatos_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó los datos de la cuenta");

            //Ingresar datos adicionales en st01 o imi01
            SYS_RMSA_ST01_IM01_Crear.Crear(Categoria, Tipo_Producto);
            //Comprobar crear cuenta
            SYS_RMSA_ST01_IM01Crear_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se ingresó el producto de la cuenta");

            //Completar o finalizar la creacion de la cuenta
            SYS_RMSA_Crear_Completar.Completar();
            //Comprobar mensaje de finalizar cuenta
            SYS_RMSACrearCompletar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Obtuvo los Movimientos de la Cuenta");
        }
    }
}
