﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    class SYS_ST30_IngresoRetenciones
    {
        [Then(@"Ingreso Retencion a la cuenta en Comando ST30 con (.*), (.*), (.*), (.*), (.*), (.*), (.*), (.*)")]
        public void ThenIngresoRetencionALaCuentaEnComandoST30Con(string Cuenta, string Moneda, string Oficina, string Categoria, string CodTransaccion, string Monto, string Descripcion, string Dias)
        {
            //Ingresar a ST30
            SYS_ST30_Ingresar.Ingresar();
            //Comprobar Ingreso a ST30
            SYS_ST30Ingresar_Comprobar.Pantalla();

            //Ingresar Retencion con los Datos
            SYS_ST30_IngresarRetencion.IngresarRetencion(Cuenta, Moneda, Oficina, Categoria, CodTransaccion, Monto, Descripcion, Dias);
            //Comprobar Ingreso de Retencion
            SYS_ST30IngresarRetencion_Comprobar.Pantalla();

            //Proximamente - Agregar Paginacion
        }
    }
}
