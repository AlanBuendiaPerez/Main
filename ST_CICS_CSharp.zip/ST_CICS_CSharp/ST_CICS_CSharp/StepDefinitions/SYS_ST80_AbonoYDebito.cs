﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SYS_ST80_AbonoYDebito
    {               
        [When(@"Ingreso al Comando ST80")]
        public static void IngresoAlComandoST80()
        {
            //Ingresar al Comando ST80 de Systematics
            SYS_ST80_Ingresar.Ingresar();
            //Comprobar Ingreso a Comando ST80 de Systematics
            SYS_ST80Ingresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó al Comando ST80 de Systematics");
        }

        [When(@"Abono a la Cuenta con (.*), (.*), (.*), (.*), (.*), (.*)")]
        public static void AbonoALaCuentaCon(string Cuenta, string Moneda, string Oficina, string Categoria, string Monto, string Descripcion)
        {
            //Proceso de Abono
            SYS_ST80_Abonar.Abonar(Cuenta, Moneda, Oficina, Categoria, Monto, Descripcion);
            //Comprobar Proceso de Abono
            SYS_ST80Abonar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Completó el Abono");
        }

        [When(@"Debito a la Cuenta con (.*), (.*), (.*), (.*), (.*), (.*)")]
        public void WhenDebitoALaCuentaCon(string Cuenta, string Moneda, string Oficina, string Categoria, string Monto, string Descripcion)
        {
            //Proceso de Debito
            SYS_ST80_Debitar.Debitar(Cuenta, Moneda, Oficina, Categoria, Monto, Descripcion);
            //Comprobar Proceso de Debito
            SYS_ST80Debitar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Completó el Abono");
        }

        [When(@"Realizo cierre de la Cuenta con (.*), (.*), (.*), (.*)")]
        public void WhenRealizoCierreDeLaCuentaCon(string Cuenta, string Moneda, string Oficina, string Categoria)
        {
            //Proceso de Debito
            SYS_ST80_CierreCuenta.Cierre(Cuenta, Moneda, Oficina, Categoria);
            //Comprobar Proceso de Debito
            SYS_ST80CierreCuenta_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Completó Cierre de Cuenta");
        }
    }
}
