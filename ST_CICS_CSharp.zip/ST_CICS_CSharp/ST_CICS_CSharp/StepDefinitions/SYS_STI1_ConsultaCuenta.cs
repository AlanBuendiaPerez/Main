﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SYS_STI1_ConsultaCuenta
    {
        [Then(@"Ingreso a la Cuenta en Comando STI1 con (.*), (.*), (.*), (.*)")]
        public static void IngresoALaCuentaEnComandoSTI1Con(string Cuenta, string Moneda, string Oficina, string Categoria)
        {
            //Ingresar a comando STI1
            SYS_STI1_Ingresar.Ingresar();
            //Comprobar Ingreso a Comando STI1
            SYS_STI1Ingresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó a Comando STI1 de Systematics");

            //Consulta de Información de Cuenta en Comando STI1

            SYS_STI1_Consultar.Consultar(Cuenta, Moneda, Oficina, Categoria);
            //Comprobar Ingreso a Comando STI1
            SYS_STI1Consultar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Consultó Cuenta en Comando STI1 de Systematics");

        }
        [Then(@"Accedo a Comisiones Pendientes Mega")]
        public static void AccedoAComisionesPendientesMega()
        {
            //Ingresar A Comisiones Pendientes Mega
            SYS_STI1_IngresarComisionMega.Ingresar();
            //Comprobar ingresar a comisiones pendientes Mega
            SYS_STI1ComisionMega_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó a Comisiones Pendientes Saving");            
        }

        [Then(@"Consulto el Detalle de Cada Comision Mega")]
        public static void ConsultoElDetalleDeCadaComisionMega()
        {
            //Ingresar A Detalle de Cada Concepto
            SYS_STI1_IngresarDetalleComisionMega.Ingresar();
            //Finalizar
            Utilidad.RegistrarLog("Se tomaron las evidencias correctamente");
        }
    }
}
