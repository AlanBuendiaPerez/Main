﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SYS_STI2_ConsultaMovimientos
    {
        [Then(@"Ingreso a la Cuenta en Comando STI2 con (.*), (.*), (.*), (.*)")]
        public static void IngresoALaCuentaEnComandoSTI2Con(string Cuenta, string Moneda, string Oficina, string Categoria)
        {
            //Ingresar a comando STI2
            SYS_STI2_Ingresar.Ingresar();
            //Comprobar Ingreso a Comando STI2
            SYS_STI2Ingresar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Ingresó a Comando STI2 de Systematics");

            //Consultar Movimientos de Cuenta en STI2
            SYS_STI2_Consultar.Consultar(Cuenta, Moneda, Oficina, Categoria);
            //Comprobar Consulta de Cuenta en STI2
            SYS_STI2Consultar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Consultó Cuenta en Comando STI2 de Systematics");

            //Consultar Movimientos en Paginas Siguientes
            SYS_STI2_Avanzar.Avanzar();
            //Comprobar Avance en Paginas Siguientes
            SYS_STI2Avanzar_Comprobar.Pantalla();
            Utilidad.RegistrarLog("Se Obtuvo los Movimientos de la Cuenta");
        }
    }
}
