﻿using Base.Utils;
using ST_CICS_CSharp.Questions;
using ST_CICS_CSharp.Tasks;
using ST_CICS_CSharp.Tasks.Comprobar;
using TechTalk.SpecFlow;

namespace ST_CICS_CSharp.StepDefinitions
{
    [Binding]
    public class SYS_STI5_ConsultarRetencionesSteps
    {
        [Then(@"Ingreso a la Cuenta en Comando STI5 con (.*), (.*), (.*), (.*)")]
        public void ThenIngresoALaCuentaEnComandoSTI5Con(string Cuenta, string Moneda, string Oficina, string Categoria)
        {
            //Ingresar a STI5
            SYS_STI5_Ingresar.Ingresar();
            //Comprobar Ingreso a STI5
            SYS_STI5Ingresar_Comprobar.Pantalla();

            //Consultar Retenciones con los Datos
            SYS_STI5_Consultar.Consultar(Cuenta, Moneda, Oficina, Categoria);
            //Comprobar Consulta de Retenciones
            SYS_STI5Consultar_Comprobar.Pantalla();

            //Proximamente - Agregar Paginacion
        }
    }
}
