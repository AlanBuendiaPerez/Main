﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    internal class AccesLogin_Credenciales
    {
        public static void Credenciales()
        {
            Posicionar.Cursor(AccesLogin_UI.Usuario.Posicion_Y, AccesLogin_UI.Usuario.Posicion_X);
            Escribir.Texto(Global.usuarioCics);
            Posicionar.Cursor(AccesLogin_UI.Contraseña.Posicion_Y, AccesLogin_UI.Contraseña.Posicion_X);
            Escribir.Texto(Global.contraseñaCics);
            //Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
