﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class CicsApp_SeleccionarSYS
    {
        public static void AccesoOpcion(string opcion)
        {
            Posicionar.Cursor(CicsApp_UI.Opcion.Posicion_Y, CicsApp_UI.Opcion.Posicion_X);
            Escribir.Texto(opcion);
            //Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
            //Utilidad.CapturarEvidenciaCics();
        }
    }
}
