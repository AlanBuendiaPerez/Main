﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class AccessLogin_Comprobar
    {
        public static void Pantalla()
        {
            if ("INTERBANK" != Obtener.Texto(AccesLogin_UI.ObtenerInterbank.Posicion_Y, AccesLogin_UI.ObtenerInterbank.Posicion_X, AccesLogin_UI.ObtenerInterbank.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla Login de Aplicaciones");
            }
        }
    }
}
