﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class CicsApp_Comprobar
    {
        public static void Pantalla()
        {
            if ("SISTEMAS" != Obtener.Texto(CicsApp_UI.ObtenerSistemas.Posicion_Y, CicsApp_UI.ObtenerSistemas.Posicion_X, CicsApp_UI.ObtenerSistemas.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla Cics Administrativo");
            }
        }
    }
}
