﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class Conexion_Comprobar
    {
        public static void Pantalla()
        {
            if ("ACCESS" != Obtener.Texto(Access_UI.ObtenerAccess.Posicion_Y, Access_UI.ObtenerAccess.Posicion_X, Access_UI.ObtenerAccess.Longitud))
            {
                CicsException.DetenerEInformar("No se pudo conectar al servidor");
            }
        }
    }
}
