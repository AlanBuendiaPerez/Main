﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class DEP_ComisionesMegaConsultar_Comprobar
    {
        public static void Pantalla()
        {
            if ("0000" != Obtener.Texto(DEP_ComisionesMega_UI.ObtenerCerosCuenta.Posicion_Y, DEP_ComisionesMega_UI.ObtenerCerosCuenta.Posicion_X, DEP_ComisionesMega_UI.ObtenerCerosCuenta.Longitud))
            {
                CicsException.DetenerEInformar("No se ingreso cuenta correctamente");
            }
        }
    }
}
