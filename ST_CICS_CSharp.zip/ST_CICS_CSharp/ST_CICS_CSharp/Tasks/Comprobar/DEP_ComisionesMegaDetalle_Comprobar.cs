﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class DEP_ComisionesMegaDetalle_Comprobar
    {
        public static void Pantalla()
        {
            if ("Depo0" != Obtener.Texto(DEP_ComisionesMegaDetalle_UI.ObtenerDepo.Posicion_Y, DEP_ComisionesMegaDetalle_UI.ObtenerDepo.Posicion_X, DEP_ComisionesMegaDetalle_UI.ObtenerDepo.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla Detalle de Comisiones Pendientes MEGA");
            }
        }
    }
}
