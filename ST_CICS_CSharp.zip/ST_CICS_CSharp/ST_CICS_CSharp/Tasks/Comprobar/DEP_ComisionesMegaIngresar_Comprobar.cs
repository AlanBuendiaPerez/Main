﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class DEP_ComisionesMegaIngresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("PENDIENTES MEGA" != Obtener.Texto(DEP_ComisionesMega_UI.ObtenerPendentesMega.Posicion_Y, DEP_ComisionesMega_UI.ObtenerPendentesMega.Posicion_X, DEP_ComisionesMega_UI.ObtenerPendentesMega.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a COMISIONES PENDIENTES MEGA");
            }
        }
    }
}
