﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class DEP_DepositosAceder_Comprobar
    {
        public static void Pantalla()
        {
            if ("D E P O S I T O S" != Obtener.Texto(DEP_Menu_UI.ObtenerDEPOSITOS.Posicion_Y, DEP_Menu_UI.ObtenerDEPOSITOS.Posicion_X, DEP_Menu_UI.ObtenerDEPOSITOS.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a Menu Depositos");
            }
        }
    }
}
