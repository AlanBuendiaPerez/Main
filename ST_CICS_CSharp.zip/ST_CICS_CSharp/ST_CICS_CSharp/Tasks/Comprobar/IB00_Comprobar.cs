﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class IB00_Comprobar
    {
        public static void Pantalla()
        {
            if ("CONSULTA" != Obtener.Texto(IB00_UI.ObtenerConsulta.Posicion_Y, IB00_UI.ObtenerConsulta.Posicion_X, IB00_UI.ObtenerConsulta.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla de la opcion IB00");
            }
        }
    }
}
