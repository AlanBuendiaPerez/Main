﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class LoginCics_Comprobar
    {
        public static void Pantalla()
        {
            if ("PATRON" != Obtener.Texto(LoginCics_UI.ObtenerConsulta.Posicion_Y, LoginCics_UI.ObtenerConsulta.Posicion_X, LoginCics_UI.ObtenerConsulta.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla de Login Cics Administrativo");
            }
        }
    }
}
