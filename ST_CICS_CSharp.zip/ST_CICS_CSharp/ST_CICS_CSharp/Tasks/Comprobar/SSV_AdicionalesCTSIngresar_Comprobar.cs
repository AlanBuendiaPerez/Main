﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SSV_AdicionalesCTSIngresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("DATOS ADICIONALES" != Obtener.Texto(SSV_DatosAdicionalesCTS_UI.ObtenerDatosAdicionales.Posicion_Y, SSV_DatosAdicionalesCTS_UI.ObtenerDatosAdicionales.Posicion_X, SSV_DatosAdicionalesCTS_UI.ObtenerDatosAdicionales.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Menu de Datos Adicionales");
            }
        }
    }
}
