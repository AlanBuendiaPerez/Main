﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SSV_SavingAcceder_Comprobar
    {
        public static void Pantalla()
        {
            if ("Administrativo Savings" != Obtener.Texto(SSV_MenuPrincipal_UI.ObtenerAdministrativoSaving.Posicion_Y, SSV_MenuPrincipal_UI.ObtenerAdministrativoSaving.Posicion_X, SSV_MenuPrincipal_UI.ObtenerAdministrativoSaving.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Menu de Administrativo Saving");
            }
        }
    }
}
