﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_RMABIngresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("CONSULTA RAPIDA" != Obtener.Texto(SYS_RMAB_UI.ObtenerConsultaRapida.Posicion_Y, SYS_RMAB_UI.ObtenerConsultaRapida.Posicion_X, SYS_RMAB_UI.ObtenerConsultaRapida.Longitud))
            {
                CicsException.DetenerEInformar("No se pudo consultar la Cuenta");
            }
        }
    }
}
