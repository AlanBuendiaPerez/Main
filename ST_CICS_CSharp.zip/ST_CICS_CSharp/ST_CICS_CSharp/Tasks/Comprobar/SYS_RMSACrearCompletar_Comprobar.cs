﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_RMSACrearCompletar_Comprobar
    {
        public static void Pantalla()
        {
            if ("SESION TERMINADO" != Obtener.Texto(SYS_RMSA_UI.ObtenerSesionTerminado.Posicion_Y, SYS_RMSA_UI.ObtenerSesionTerminado.Posicion_X, SYS_RMSA_UI.ObtenerSesionTerminado.Longitud))
            {
                CicsException.DetenerEInformar("No se finalizó la creación de la cuenta");
            }
        }
    }
}
