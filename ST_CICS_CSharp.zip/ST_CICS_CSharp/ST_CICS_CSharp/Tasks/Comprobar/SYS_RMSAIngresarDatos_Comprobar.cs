﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_RMSAIngresarDatos_Comprobar
    {
        public static void Pantalla()
        {
            if ("NEW ACCOUNT" == Obtener.Texto(SYS_ST01_UI.ObtenerNewAccount.Posicion_Y, SYS_ST01_UI.ObtenerNewAccount.Posicion_X, SYS_ST01_UI.ObtenerNewAccount.Longitud))
            {
                return;
            }
            else if ("NUEVA DE IMPACS" == Obtener.Texto(SYS_IM01_UI.ObtenerNuevaImpacs.Posicion_Y, SYS_IM01_UI.ObtenerNuevaImpacs.Posicion_X, SYS_IM01_UI.ObtenerNuevaImpacs.Longitud))
            {
                return;
            }
            else
            {
                CicsException.DetenerEInformar("No accedió a la pantalla de la opcion IB00");
            }
        }
    }
}
