﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_RMSAIngresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("APERTURA CUENTA" != Obtener.Texto(SYS_RMSA_UI.ObtenerAperturaCuenta.Posicion_Y, SYS_RMSA_UI.ObtenerAperturaCuenta.Posicion_X, SYS_RMSA_UI.ObtenerAperturaCuenta.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a RMSA - Apertura de Cuenta");
            }
        }
    }
}
