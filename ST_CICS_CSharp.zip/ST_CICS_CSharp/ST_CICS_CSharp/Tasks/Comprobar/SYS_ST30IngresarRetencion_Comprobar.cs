﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_ST30IngresarRetencion_Comprobar
    {
        public static void Pantalla()
        {
            if ("Processing complete" != Obtener.Texto(SYS_ST30_UI.ObtenerProcesoCompleto.Posicion_Y, SYS_ST30_UI.ObtenerProcesoCompleto.Posicion_X, SYS_ST30_UI.ObtenerProcesoCompleto.Longitud))
            {
                CicsException.DetenerEInformar("No se Ingreso la Retencion");
            }
        }
    }
}
