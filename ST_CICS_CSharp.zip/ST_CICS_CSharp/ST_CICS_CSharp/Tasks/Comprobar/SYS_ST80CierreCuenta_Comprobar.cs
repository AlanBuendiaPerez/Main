﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_ST80CierreCuenta_Comprobar
    {
        public static void Pantalla()
        {
            if ("CLOSED" != Obtener.Texto(SYS_STI1_UI.ObtenerEstadoClosed.Posicion_Y, SYS_STI1_UI.ObtenerEstadoClosed.Posicion_X, SYS_STI1_UI.ObtenerEstadoClosed.Longitud))
            {
                    CicsException.DetenerEInformar("No se completó el Cierre");      
            }
        }
    }
}