﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_ST80Debitar_Comprobar
    {
        public static void Pantalla()
        {
            if ("Processing complete" != Obtener.Texto(SYS_ST80_UI.ObtenerCompleto.Posicion_Y, SYS_ST80_UI.ObtenerCompleto.Posicion_X, SYS_ST80_UI.ObtenerCompleto.Longitud))
            {
                if ("MONETARY ACTIVITY ON ACCOUNT TODAY" != Obtener.Texto(SYS_ST80_UI.ObtenerExitoAbono.Posicion_Y, SYS_ST80_UI.ObtenerExitoAbono.Posicion_X, SYS_ST80_UI.ObtenerExitoAbono.Longitud))
                {
                    CicsException.DetenerEInformar("No se completó el Abono");
                }
            }
        }
    }
}
