﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_ST80Ingresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("TRANSACCIONES MONETARIAS" != Obtener.Texto(SYS_ST80_UI.ObtenerTransaccionesMonetarias.Posicion_Y, SYS_ST80_UI.ObtenerTransaccionesMonetarias.Posicion_X, SYS_ST80_UI.ObtenerTransaccionesMonetarias.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Comando ST80 de Systematics");
            }
        }
    }
}
