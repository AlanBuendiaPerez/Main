﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI1ComisionMega_Comprobar
    {
        public static void Pantalla()
        {
            if ("COMISIONES  PENDIENTES" != Obtener.Texto(SYS_STI1_ComisionesPendientes_UI.ObtenerComisionesPendientes.Posicion_Y, SYS_STI1_ComisionesPendientes_UI.ObtenerComisionesPendientes.Posicion_X, SYS_STI1_ComisionesPendientes_UI.ObtenerComisionesPendientes.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Comisiones Pendientes STI1");
            }
        }
    }
}
