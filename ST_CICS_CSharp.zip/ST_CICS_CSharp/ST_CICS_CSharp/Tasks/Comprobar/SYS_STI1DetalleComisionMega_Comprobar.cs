﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI1DetalleComisionMega_Comprobar
    {
        //cambiar todo aqui menos el mensaje
        public static void Pantalla()
        {
            if ("DETALLE DE COMISIONES" != Obtener.Texto(SYS_STI1_DealleComisionesPendientes_UI.ObtenerDetalleComisiones.Posicion_Y, SYS_STI1_DealleComisionesPendientes_UI.ObtenerDetalleComisiones.Posicion_X, SYS_STI1_DealleComisionesPendientes_UI.ObtenerDetalleComisiones.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Detalle de Comisiones Pendientes Saving");
            }
        }
    }
}
