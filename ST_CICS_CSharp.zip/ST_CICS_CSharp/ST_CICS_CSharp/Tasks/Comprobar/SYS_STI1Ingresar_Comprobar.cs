﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI1Ingresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("INFORMACION DE CUENTAS" != Obtener.Texto(SYS_STI1_UI.ObtenerInformacionDeCuentas.Posicion_Y, SYS_STI1_UI.ObtenerInformacionDeCuentas.Posicion_X, SYS_STI1_UI.ObtenerInformacionDeCuentas.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Comando STI1 de Systematics");
            }
        }
    }
}
