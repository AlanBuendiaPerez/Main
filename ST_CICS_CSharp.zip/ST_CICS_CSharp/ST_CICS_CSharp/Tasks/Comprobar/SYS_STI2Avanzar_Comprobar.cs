﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI2Avanzar_Comprobar
    {
        public static void Pantalla()
        {
            if ("NO PUEDE ADELANTARSE" == Obtener.Texto(SYS_STI2_UI.ObtenerNoAdelantar.Posicion_Y, SYS_STI2_UI.ObtenerNoAdelantar.Posicion_X, SYS_STI2_UI.ObtenerNoAdelantar.Longitud))
            {
                return;
            }
            else if ("LAST PAGE" == Obtener.Texto(SYS_STI2_UI.ObtenerLastPage.Posicion_Y, SYS_STI2_UI.ObtenerLastPage.Posicion_X, SYS_STI2_UI.ObtenerLastPage.Longitud))
            {
                return;
            }
            else
            {
                CicsException.DetenerEInformar("No se Obtuvo Los Movimientos de Cuenta");
            }
        }
    }
}
