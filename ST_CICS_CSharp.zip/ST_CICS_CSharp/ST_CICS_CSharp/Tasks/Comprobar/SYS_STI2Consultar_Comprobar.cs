﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI2Consultar_Comprobar
    {
        public static void Pantalla()
        {
            if ("RECORD NOT FOUND" == Obtener.Texto(SYS_STI2_UI.ObtenerCuentaNoExiste.Posicion_Y, SYS_STI2_UI.ObtenerCuentaNoExiste.Posicion_X, SYS_STI2_UI.ObtenerCuentaNoExiste.Longitud))
            {
                CicsException.DetenerEInformar("No Se Obtuvo la Informacion de la Cuenta");
            }
            else if ("NO HIST FOUND" == Obtener.Texto(SYS_STI2_UI.ObtenerCuentaSinHistorico.Posicion_Y, SYS_STI2_UI.ObtenerCuentaSinHistorico.Posicion_X, SYS_STI2_UI.ObtenerCuentaSinHistorico.Longitud))
            {
                CicsException.DetenerEInformar("No Se Obtuvo la Informacion de la Cuenta");
            }
            else
            {
                return;
            }
        }
    }
}
