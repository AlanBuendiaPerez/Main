﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI2Ingresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("CONSULTA HISTORICO" != Obtener.Texto(SYS_STI2_UI.ObtenerConsultaHistorico.Posicion_Y, SYS_STI2_UI.ObtenerConsultaHistorico.Posicion_X, SYS_STI2_UI.ObtenerConsultaHistorico.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Comando STI2 de Systematics");
            }
        }
    }
}
