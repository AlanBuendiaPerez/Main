﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI5Consultar_Comprobar
    {
        public static void Pantalla()
        {
            if ("REG NO ENC STMEM" == Obtener.Texto(SYS_STI5_UI.ObtenerCuentaNoExiste.Posicion_Y, SYS_STI5_UI.ObtenerCuentaNoExiste.Posicion_X, SYS_STI5_UI.ObtenerCuentaNoExiste.Longitud))
            {
                CicsException.DetenerEInformar("No existe la cuenta ingresada");
            }
            else
            {
                return;
            }
        }
    }
}
