﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SYS_STI5Ingresar_Comprobar
    {
        public static void Pantalla()
        {
            if ("CONSULTA ONP/RETENC" != Obtener.Texto(SYS_STI5_UI.ObtenerConsultaRetencion.Posicion_Y, SYS_STI5_UI.ObtenerConsultaRetencion.Posicion_X, SYS_STI5_UI.ObtenerConsultaRetencion.Longitud))
            {
                CicsException.DetenerEInformar("No accedió al Comando STI5 de Systematics");
            }
        }
    }
}
