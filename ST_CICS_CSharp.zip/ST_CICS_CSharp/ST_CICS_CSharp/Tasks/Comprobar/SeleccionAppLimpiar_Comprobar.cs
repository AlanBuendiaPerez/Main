﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SeleccionAppLimpiar_Comprobar
    {
        public static void Pantalla()
        {
            if ("You are already logged off from the application." == Obtener.Texto(SeleccionApp_UI.ObtenerSesionCerrada.Posicion_Y, SeleccionApp_UI.ObtenerSesionCerrada.Posicion_X, SeleccionApp_UI.ObtenerSesionCerrada.Longitud))
            {
                return;
            }
            else if("You are now logged off from the application." == Obtener.Texto(SeleccionApp_UI.ObtenerSesionAhoraCerrada.Posicion_Y, SeleccionApp_UI.ObtenerSesionAhoraCerrada.Posicion_X, SeleccionApp_UI.ObtenerSesionAhoraCerrada.Longitud))
            {
                return;
            }
            else
            {
                CicsException.DetenerEInformar("No se pudo cerrar la sesión");
            }
        }
    }
}
