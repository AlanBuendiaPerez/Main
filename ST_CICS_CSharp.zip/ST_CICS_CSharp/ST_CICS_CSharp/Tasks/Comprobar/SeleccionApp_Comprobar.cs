﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SeleccionApp_Comprobar
    {
        public static void Pantalla()
        {
            if ("Seleccion" != Obtener.Texto(SeleccionApp_UI.ObtenerAplicaciones.Posicion_Y, SeleccionApp_UI.ObtenerAplicaciones.Posicion_X, SeleccionApp_UI.ObtenerAplicaciones.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla de Aplicaciones");
            }
        }
    }
}
