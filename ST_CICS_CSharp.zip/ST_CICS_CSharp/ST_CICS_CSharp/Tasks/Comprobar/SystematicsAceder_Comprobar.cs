﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SystematicsAceder_Comprobar
    {
        public static void Pantalla()
        {
            if ("MENU" == Obtener.Texto(Systematics_UI.ObtenerMenu.Posicion_Y, Systematics_UI.ObtenerMenu.Posicion_X, Systematics_UI.ObtenerMenu.Longitud))
            {
                return;
            }
            else if ("USUARIO NO REGISTRADO" == Obtener.Texto(Systematics_UI.ObtenerNoRegistrado.Posicion_Y, Systematics_UI.ObtenerNoRegistrado.Posicion_X, Systematics_UI.ObtenerNoRegistrado.Longitud))
            {
                CicsException.DetenerEInformar("No accedió a la pantalla Menu de Systematics - Usuario No Registrado");
            }
            else
            {
                CicsException.DetenerEInformar("No accedió a la pantalla Menu de Systematics");
            }
        }
    }
}
