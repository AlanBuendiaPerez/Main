﻿using Base.Exceptions;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;

namespace ST_CICS_CSharp.Tasks.Comprobar
{
    class SystematicsLimpiar_Comprobar
    {
        public static void Pantalla()
        {
            if (string.Empty != Obtener.Texto(Systematics_UI.ObtenerCampoVacio.Posicion_Y, Systematics_UI.ObtenerCampoVacio.Posicion_X, Systematics_UI.ObtenerCampoVacio.Longitud).Trim())
            {
                CicsException.DetenerEInformar("No se pudo limpiar la pantalla");
            }
        }
    }
}
