﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class DEP_ComisionesMegaDetalle_Avanzar
    {
        public static void Avanzar()
        {
            bool conDetalle = true;
            while (conDetalle)
            {
                Utilidad.CapturarEvidenciaCics();
                Presionar.Tecla(TnKey.F8);

                Thread.Sleep(Global.tiempo);

                string sinregistros = Obtener.Texto(DEP_ComisionesMegaDetalle_UI.ObtenerSinRegistros.Posicion_Y, DEP_ComisionesMegaDetalle_UI.ObtenerSinRegistros.Posicion_X, DEP_ComisionesMegaDetalle_UI.ObtenerSinRegistros.Longitud);
                if (sinregistros == "NO HAY MAS REGISTROS")
                {
                    Presionar.Tecla(TnKey.F3);

                    Presionar.Tecla(TnKey.F7);
                    break;
                }
            }
        }
    }
}
