﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class DEP_ComisionesMega_Consultar
    {
        public static void Consultar(string moneda, string oficina, string categoria, string cuenta)
        {
            Posicionar.Cursor(DEP_ComisionesMega_UI.ObtenerMoneda.Posicion_Y, DEP_ComisionesMega_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto(moneda);

            Posicionar.Cursor(DEP_ComisionesMega_UI.ObtenerOficina.Posicion_Y, DEP_ComisionesMega_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto(oficina);

            Posicionar.Cursor(DEP_ComisionesMega_UI.ObtenerCategoria.Posicion_Y, DEP_ComisionesMega_UI.ObtenerCategoria.Posicion_X);
            Escribir.Texto(categoria);

            Posicionar.Cursor(DEP_ComisionesMega_UI.ObtenerCuenta.Posicion_Y, DEP_ComisionesMega_UI.ObtenerCuenta.Posicion_X);
            Escribir.Texto(cuenta);

            Presionar.Tecla(TnKey.Enter);
            Utilidad.CapturarEvidenciaCics();

            Thread.Sleep(Global.tiempo);
        }
    }
}
