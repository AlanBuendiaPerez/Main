﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;
using ST_CICS_CSharp.Tasks.Comprobar;

namespace ST_CICS_CSharp.Tasks
{
    class DEP_ComisionesMega_Detalle
    {
        public enum posicion { }
        public static void Detalle()
        {
            int Posicion_Y;
            for (Posicion_Y = 9; Posicion_Y <= 20; Posicion_Y++)
            {
                posicion pos = (posicion)Posicion_Y;
                string concepto = Obtener.Texto(pos, DEP_ComisionesMega_UI.ObtenerConceptoOrden.Posicion_X, DEP_ComisionesMega_UI.ObtenerConceptoOrden.Longitud).Trim();
                if (concepto != string.Empty)
                {
                    Posicionar.Cursor(pos, DEP_ComisionesMega_UI.ObtenerCursorConcepto.Posicion_X);
                    Escribir.Texto("X");
                    Presionar.Tecla(TnKey.Enter);
                    Thread.Sleep(Global.tiempo);

                    DEP_ComisionesMegaDetalle_Comprobar.Pantalla();

                    DEP_ComisionesMegaDetalle_Avanzar.Avanzar();

                    if (Posicion_Y == 20)
                    {
                        Presionar.Tecla(TnKey.F8);
                        string sinConceptos = Obtener.Texto(DEP_ComisionesMega_UI.ObtenerSinRegistros.Posicion_Y, DEP_ComisionesMega_UI.ObtenerSinRegistros.Posicion_X, DEP_ComisionesMega_UI.ObtenerSinRegistros.Longitud);
                        if (sinConceptos != "NO HAY MAS REGISTROS")
                        {
                            Posicion_Y = 9;
                        }
                    }
                }
                else
                {
                    break;
                }

            }
        }
    }
}
