﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class DEP_ComisionesMega_Ingresar
    {
        public static void Ingresar(string Opcion)
        {
            Posicionar.Cursor(DEP_Menu_UI.ObtenerCursor.Posicion_Y, DEP_Menu_UI.ObtenerCursor.Posicion_X);
            Escribir.Texto(Opcion);
            Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
