﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class IB00_Ingresar
    {
        public static void Ingresar()
        {
            Posicionar.Cursor(IB00_UI.Consulta.Posicion_Y, IB00_UI.Consulta.Posicion_X);
            Escribir.Texto("IB00");
            //Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
