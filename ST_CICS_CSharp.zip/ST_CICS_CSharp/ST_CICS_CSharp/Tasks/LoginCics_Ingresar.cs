﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class LoginCics_Ingresar
    {
        public static void Credenciales()
        {
            Posicionar.Cursor(LoginCics_UI.Usuario.Posicion_Y, LoginCics_UI.Usuario.Posicion_X);
            Escribir.Texto(Global.usuarioCics);
            Posicionar.Cursor(LoginCics_UI.Contraseña.Posicion_Y, LoginCics_UI.Contraseña.Posicion_X);
            Escribir.Texto(Global.contraseñaCics);
            //Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
