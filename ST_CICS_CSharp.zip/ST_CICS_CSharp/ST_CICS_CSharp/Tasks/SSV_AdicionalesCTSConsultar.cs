﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SSV_AdicionalesCTSConsultar
    {
        public static void Consultar(string moneda, string oficina, string cuenta)
        {
            Posicionar.Cursor(SSV_DatosAdicionalesCTS_UI.ObtenerMoneda.Posicion_Y, SSV_DatosAdicionalesCTS_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto(moneda);

            Posicionar.Cursor(SSV_DatosAdicionalesCTS_UI.ObtenerOficina.Posicion_Y, SSV_DatosAdicionalesCTS_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto(oficina);

            Posicionar.Cursor(SSV_DatosAdicionalesCTS_UI.ObtenerCuenta.Posicion_Y, SSV_DatosAdicionalesCTS_UI.ObtenerCuenta.Posicion_X);
            Escribir.Texto(cuenta);

            Presionar.Tecla(TnKey.Enter);
            Thread.Sleep(Global.tiempo);
            Utilidad.CapturarEvidenciaCics();

        }
    }
}
