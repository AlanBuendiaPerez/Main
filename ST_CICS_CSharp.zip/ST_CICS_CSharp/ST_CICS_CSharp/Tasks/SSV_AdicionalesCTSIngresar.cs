﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SSV_AdicionalesCTSIngresar
    {
        public static void Ingresar(string empleado)
        {
            Posicionar.Cursor(SSV_MenuPrincipal_UI.ObtenerOpcion.Posicion_Y, SSV_MenuPrincipal_UI.ObtenerOpcion.Posicion_X);

            if (empleado == "si")
            {
                Escribir.Texto("04");
            }
            else
            {
                Escribir.Texto("03");
            }

            Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
