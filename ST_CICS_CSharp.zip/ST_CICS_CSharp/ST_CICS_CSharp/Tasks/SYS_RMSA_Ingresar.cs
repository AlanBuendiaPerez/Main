﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_RMSA_Ingresar
    {
        public static void Ingresar()
        {
            Presionar.Tecla(TnKey.F9);
            Utilidad.CapturarEvidenciaCics();
            Thread.Sleep(Global.tiempo);
        }
    }
}
