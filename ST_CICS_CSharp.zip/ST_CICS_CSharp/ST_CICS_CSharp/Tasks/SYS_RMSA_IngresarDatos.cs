﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_RMSA_IngresarDatos
    {
        public static void Ingresar(string moneda, string oficina, string categoria, string tipo_producto)
        {
            if (categoria.Equals("001"))
            {
                Posicionar.Cursor(SYS_RMSA_UI.ObtenerPosicionImpacs.Posicion_Y, SYS_RMSA_UI.ObtenerPosicionImpacs.Posicion_X);
                Escribir.Texto("1");
                Posicionar.Cursor(SYS_RMSA_UI.ObtenerPosicionAplicativo.Posicion_Y, SYS_RMSA_UI.ObtenerPosicionAplicativo.Posicion_X);
                Escribir.Texto("IM");
            }
            else
            {
                Posicionar.Cursor(SYS_RMSA_UI.ObtenerPosicionSaving.Posicion_Y, SYS_RMSA_UI.ObtenerPosicionSaving.Posicion_X);
                Escribir.Texto("1");
                Posicionar.Cursor(SYS_RMSA_UI.ObtenerPosicionAplicativo.Posicion_Y, SYS_RMSA_UI.ObtenerPosicionAplicativo.Posicion_X);
                Escribir.Texto("ST");
            }

            Posicionar.Cursor(SYS_RMSA_UI.ObtenerBanco.Posicion_Y, SYS_RMSA_UI.ObtenerBanco.Posicion_X);
            Escribir.Texto("0003");

            Posicionar.Cursor(SYS_RMSA_UI.ObtenerMoneda.Posicion_Y, SYS_RMSA_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto("0" + moneda);

            Posicionar.Cursor(SYS_RMSA_UI.ObtenerOficina.Posicion_Y, SYS_RMSA_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto("0" + oficina);

            Posicionar.Cursor(SYS_RMSA_UI.ObtenerCategoria.Posicion_Y, SYS_RMSA_UI.ObtenerCategoria.Posicion_X);
            Escribir.Texto("0" + categoria);

            Posicionar.Cursor(SYS_RMSA_UI.ObtenerCodConexion.Posicion_Y, SYS_RMSA_UI.ObtenerCodConexion.Posicion_X);
            Escribir.Texto("IND");

            Posicionar.Cursor(SYS_RMSA_UI.ObtenerPosicion01.Posicion_Y, SYS_RMSA_UI.ObtenerPosicion01.Posicion_X);
            Escribir.Texto("1");

            Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Utilidad.CapturarEvidenciaCics();

            Thread.Sleep(Global.tiempo);
        }
    }
}
