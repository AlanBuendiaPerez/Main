﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_RMSA_ST01_IM01_Crear
    {
        public static void Crear(string categoria, string tipo_producto)
        {
            string cuenta;
            if (categoria.Equals("001"))
            {
                Posicionar.Cursor(SYS_IM01_UI.ObtenerTipoProducto.Posicion_Y, SYS_IM01_UI.ObtenerTipoProducto.Posicion_X);
                Escribir.Texto(tipo_producto);

                cuenta = Obtener.Texto(SYS_IM01_UI.ObtenerNumeroCuenta.Posicion_Y, SYS_IM01_UI.ObtenerNumeroCuenta.Posicion_X, SYS_IM01_UI.ObtenerNumeroCuenta.Longitud);
            }
            else
            {   
                if (categoria.Equals("002") | categoria.Equals("007"))
                {
                    Posicionar.Cursor(SYS_ST01_UI.ObtenerTipoProducto.Posicion_Y, SYS_ST01_UI.ObtenerTipoProducto.Posicion_X);
                    Escribir.Texto(tipo_producto);

                    Posicionar.Cursor(SYS_ST01_UI.ObtenerAplicacion.Posicion_Y, SYS_ST01_UI.ObtenerAplicacion.Posicion_X);
                    Escribir.Texto("1");                    
                }
                else
                {
                    Posicionar.Cursor(SYS_ST01_UI.ObtenerTipoProducto.Posicion_Y, SYS_ST01_UI.ObtenerTipoProducto.Posicion_X);
                    Escribir.Texto(tipo_producto);

                    Posicionar.Cursor(SYS_ST01_UI.ObtenerAplicacion.Posicion_Y, SYS_ST01_UI.ObtenerAplicacion.Posicion_X);
                    Escribir.Texto("3");
                }
                cuenta = Obtener.Texto(SYS_ST01_UI.ObtenerNumeroCuenta.Posicion_Y, SYS_ST01_UI.ObtenerNumeroCuenta.Posicion_X, SYS_ST01_UI.ObtenerNumeroCuenta.Longitud);

            }

            Global.resultado.Add(cuenta);

            Utilidad.CapturarEvidenciaCics();

            Presionar.Tecla(TnKey.F9);
            Thread.Sleep(Global.tiempo);
        }
    }
}
