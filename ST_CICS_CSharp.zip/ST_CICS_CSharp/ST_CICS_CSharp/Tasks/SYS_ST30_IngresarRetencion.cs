﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;
using System;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_ST30_IngresarRetencion
    {
        public static void IngresarRetencion(string cuenta, string moneda, string oficina, string categoria, string codtransaccion, string monto, string descripcion, string dias)
        {
            Posicionar.Cursor(SYS_ST30_UI.ObtenerCuenta.Posicion_Y, SYS_ST30_UI.ObtenerCuenta.Posicion_X);
            Escribir.Texto(cuenta);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerMoneda.Posicion_Y, SYS_ST30_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto(moneda);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerOficina.Posicion_Y, SYS_ST30_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto(oficina);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerCategoria.Posicion_Y, SYS_ST30_UI.ObtenerCategoria.Posicion_X);
            Escribir.Texto(categoria);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerCodTransaccion.Posicion_Y, SYS_ST30_UI.ObtenerCodTransaccion.Posicion_X);
            Escribir.Texto(codtransaccion);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerMonto.Posicion_Y, SYS_ST30_UI.ObtenerMonto.Posicion_X);
            Escribir.Texto(monto);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerDescripcion.Posicion_Y, SYS_ST30_UI.ObtenerDescripcion.Posicion_X);
            Escribir.Texto(descripcion);

            Posicionar.Cursor(SYS_ST30_UI.ObtenerDias.Posicion_Y, SYS_ST30_UI.ObtenerDias.Posicion_X);
            Escribir.Texto(dias);

            
            Presionar.Tecla(TnKey.Enter);
            Utilidad.CapturarEvidenciaCics();
            
            Thread.Sleep(Global.tiempo);
        }
    }
}