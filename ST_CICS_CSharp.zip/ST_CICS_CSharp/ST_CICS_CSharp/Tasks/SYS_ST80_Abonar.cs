﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_ST80_Abonar
    {
        public static void Abonar(string cuenta, string moneda, string oficina, string categoria, string monto, string descripcion)
        {            
            Posicionar.Cursor(SYS_ST80_UI.ObtenerCuenta.Posicion_Y, SYS_ST80_UI.ObtenerCuenta.Posicion_X);
            Escribir.Texto(cuenta);
            
            Posicionar.Cursor(SYS_ST80_UI.ObtenerMoneda.Posicion_Y, SYS_ST80_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto(moneda);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerOficina.Posicion_Y, SYS_ST80_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto(oficina);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerCategoria.Posicion_Y, SYS_ST80_UI.ObtenerCategoria.Posicion_X);
            Escribir.Texto(categoria);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerTipoOperacion.Posicion_Y, SYS_ST80_UI.ObtenerTipoOperacion.Posicion_X);
            Escribir.Texto("C");

            Posicionar.Cursor(SYS_ST80_UI.ObtenerTransaccion.Posicion_Y, SYS_ST80_UI.ObtenerTransaccion.Posicion_X);
            Escribir.Texto("1200");

            Posicionar.Cursor(SYS_ST80_UI.ObtenerMonto.Posicion_Y, SYS_ST80_UI.ObtenerMonto.Posicion_X);
            Escribir.Texto(monto);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerDescripcion.Posicion_Y, SYS_ST80_UI.ObtenerDescripcion.Posicion_X);
            Escribir.Texto(descripcion);
            
            Presionar.Tecla(TnKey.Enter);

            Utilidad.CapturarEvidenciaCics();
            
            Thread.Sleep(Global.tiempo);
        }
    }
}