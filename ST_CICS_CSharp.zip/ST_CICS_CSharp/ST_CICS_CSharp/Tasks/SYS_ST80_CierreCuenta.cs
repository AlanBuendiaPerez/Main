﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_ST80_CierreCuenta
    {
        public static void Cierre(string cuenta, string moneda, string oficina, string categoria)
        {
            Posicionar.Cursor(SYS_ST80_UI.ObtenerCuenta.Posicion_Y, SYS_ST80_UI.ObtenerCuenta.Posicion_X);
            Escribir.Texto(cuenta);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerMoneda.Posicion_Y, SYS_ST80_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto(moneda);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerOficina.Posicion_Y, SYS_ST80_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto(oficina);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerCategoria.Posicion_Y, SYS_ST80_UI.ObtenerCategoria.Posicion_X);
            Escribir.Texto(categoria);

            Posicionar.Cursor(SYS_ST80_UI.ObtenerTipoOperacion.Posicion_Y, SYS_ST80_UI.ObtenerTipoOperacion.Posicion_X);
            Escribir.Texto("D");

            Posicionar.Cursor(SYS_ST80_UI.ObtenerTransaccion.Posicion_Y, SYS_ST80_UI.ObtenerTransaccion.Posicion_X);
            Escribir.Texto("4399");

            Posicionar.Cursor(SYS_ST80_UI.ObtenerTipoDeb.Posicion_Y, SYS_ST80_UI.ObtenerTipoDeb.Posicion_X);
            Escribir.Texto("C");

            Posicionar.Cursor(SYS_ST80_UI.ObtenerDescripcion.Posicion_Y, SYS_ST80_UI.ObtenerDescripcion.Posicion_X);
            Escribir.Texto("N/D CANCELACION");
            
            Presionar.Tecla(TnKey.Enter);
            Utilidad.CapturarEvidenciaCics();

            Posicionar.Cursor(SYS_ST80_UI.ObtenerProcesarCancelacion.Posicion_Y, SYS_ST80_UI.ObtenerProcesarCancelacion.Posicion_X);
            Escribir.Texto("Y");

            Presionar.Tecla(TnKey.Enter);
            Presionar.Tecla(TnKey.F3);
            Utilidad.CapturarEvidenciaCics();


            Thread.Sleep(Global.tiempo);
        }
    }
}