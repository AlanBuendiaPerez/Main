﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_STI1_AvanzarDetalleComisionMega
    {
        public static void DetalleDeConcepto()
        {
            bool conDetalle = true;
            while (conDetalle)
            {
                Utilidad.CapturarEvidenciaCics();
                Presionar.Tecla(TnKey.F8);

                Thread.Sleep(Global.tiempo);

                string sinregistros = Obtener.Texto(SYS_STI1_DealleComisionesPendientes_UI.ObtenerSinRegistros.Posicion_Y, SYS_STI1_DealleComisionesPendientes_UI.ObtenerSinRegistros.Posicion_X, SYS_STI1_DealleComisionesPendientes_UI.ObtenerSinRegistros.Longitud);
                if (sinregistros == "NO HAY MAS REGISTROS")
                {
                    Presionar.Tecla(TnKey.F3);
                    break;
                }
            }
        }
    }
}
