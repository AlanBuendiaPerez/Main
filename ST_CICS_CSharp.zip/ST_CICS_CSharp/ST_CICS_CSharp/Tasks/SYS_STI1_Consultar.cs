﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_STI1_Consultar
    {
        public static void Consultar(string cuenta, string moneda, string oficina, string categoria)
        {
            Posicionar.Cursor(SYS_STI1_UI.ObtenerCuenta.Posicion_Y, SYS_STI1_UI.ObtenerCuenta.Posicion_X);
            Escribir.Texto(cuenta);

            Posicionar.Cursor(SYS_STI1_UI.ObtenerMoneda.Posicion_Y, SYS_STI1_UI.ObtenerMoneda.Posicion_X);
            Escribir.Texto(moneda);

            Posicionar.Cursor(SYS_STI1_UI.ObtenerOficina.Posicion_Y, SYS_STI1_UI.ObtenerOficina.Posicion_X);
            Escribir.Texto(oficina);

            Posicionar.Cursor(SYS_STI1_UI.ObtenerCategoria.Posicion_Y, SYS_STI1_UI.ObtenerCategoria.Posicion_X);
            Escribir.Texto(categoria);


            Presionar.Tecla(TnKey.Enter);
            Utilidad.CapturarEvidenciaCics();

            Thread.Sleep(Global.tiempo);
        }
    }
}
