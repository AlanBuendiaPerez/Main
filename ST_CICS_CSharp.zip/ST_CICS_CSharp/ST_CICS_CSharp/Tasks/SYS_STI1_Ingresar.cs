﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_STI1_Ingresar
    {
        public static void Ingresar()
        {
            Escribir.Texto("STI1");
            Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
