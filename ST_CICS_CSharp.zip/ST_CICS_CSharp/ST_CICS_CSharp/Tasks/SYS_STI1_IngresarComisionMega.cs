﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_STI1_IngresarComisionMega
    {
        public static void Ingresar()
        {
            Presionar.Tecla(TnKey.F10);
            Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
