﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;
using ST_CICS_CSharp.Tasks.Comprobar;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_STI1_IngresarDetalleComisionMega
    {
        public enum posicion { }
        public static void Ingresar()
        {
            int Posicion_Y;
            for (Posicion_Y = 8; Posicion_Y <= 20; Posicion_Y++)
            {
                posicion pos = (posicion)Posicion_Y;
                string concepto = Obtener.Texto(pos, SYS_STI1_ComisionesPendientes_UI.ConceptoOrden.Posicion_X, SYS_STI1_ComisionesPendientes_UI.ConceptoOrden.Longitud).Trim();
                if (concepto != string.Empty)
                {
                    Posicionar.Cursor(pos, SYS_STI1_ComisionesPendientes_UI.CursorOrden.Posicion_X);
                    Escribir.Texto("X");
                    Presionar.Tecla(TnKey.Enter);
                    Thread.Sleep(Global.tiempo);

                    SYS_STI1DetalleComisionMega_Comprobar.Pantalla();

                    SYS_STI1_AvanzarDetalleComisionMega.DetalleDeConcepto();

                    if (Posicion_Y == 20)
                    {
                        Presionar.Tecla(TnKey.F8);
                        string sinConceptos = Obtener.Texto(SYS_STI1_ComisionesPendientes_UI.ObtenerSinRegistros.Posicion_Y, SYS_STI1_ComisionesPendientes_UI.ObtenerSinRegistros.Posicion_X, SYS_STI1_ComisionesPendientes_UI.ObtenerSinRegistros.Longitud);
                        if (sinConceptos != "NO HAY MAS REGISTROS")
                        {
                            Posicion_Y = 8;
                        }
                    }
                }
                else
                {
                    break;
                }

            }
        }
    }
}
