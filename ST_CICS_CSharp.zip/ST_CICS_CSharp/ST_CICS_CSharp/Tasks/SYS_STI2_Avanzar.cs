﻿using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class SYS_STI2_Avanzar
    {
        public static void Avanzar()
        {
            string LastPage = Obtener.Texto(SYS_STI2_UI.ObtenerLastPage.Posicion_Y, SYS_STI2_UI.ObtenerLastPage.Posicion_X, SYS_STI2_UI.ObtenerLastPage.Longitud);

            //si es diferente accion else return

            if ("LAST PAGE" != LastPage)
            {
                bool contMovimiento = true;
                while (contMovimiento)
                {
                    Utilidad.CapturarEvidenciaCics();
                    Presionar.Tecla(TnKey.F1);

                    Thread.Sleep(Global.tiempo);

                    string LastPage2 = Obtener.Texto(SYS_STI2_UI.ObtenerLastPage.Posicion_Y, SYS_STI2_UI.ObtenerLastPage.Posicion_X, SYS_STI2_UI.ObtenerLastPage.Longitud);
                    if ("LAST PAGE" == LastPage2)
                    {
                        Utilidad.CapturarEvidenciaCics();
                        Thread.Sleep(Global.tiempo);
                        contMovimiento = false;
                    }
                }
            }
            else if ("LAST PAGE" == LastPage) {
                Utilidad.CapturarEvidenciaCics();
                Presionar.Tecla(TnKey.F1);

                Thread.Sleep(Global.tiempo);
            }
            else
            {
                return;
            }

        }



    }
}
