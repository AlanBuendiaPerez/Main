﻿using Open3270;
using System.Threading;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;

namespace ST_CICS_CSharp.Tasks
{
    internal class SeleccionarApp_Limpiar
    {
        public static void Opcion(string opcion)
        {
            Posicionar.Cursor(SeleccionApp_UI.Command.Posicion_Y, SeleccionApp_UI.Command.Posicion_X);
            Escribir.Texto("LF_" + opcion);

            //Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
