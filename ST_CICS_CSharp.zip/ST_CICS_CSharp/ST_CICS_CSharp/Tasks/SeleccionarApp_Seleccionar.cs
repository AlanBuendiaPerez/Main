﻿using System.Threading;
using Open3270;
using Base.Interactions;
using ST_CICS_CSharp.UserInterfaces;
using Base.Utils;

namespace ST_CICS_CSharp.Tasks
{
    class SeleccionarApp_Seleccionar
    {
        public static void AccesoOpcion(string opcion)
        {
            Posicionar.Cursor(SeleccionApp_UI.Command.Posicion_Y, SeleccionApp_UI.Command.Posicion_X);
            Escribir.Texto(opcion);
            //Utilidad.CapturarEvidenciaCics();
            Presionar.Tecla(TnKey.Enter);

            Thread.Sleep(Global.tiempo);
        }
    }
}
