﻿using Open3270;
using Base.Interactions;
using Base.Utils;
using System.Threading;

namespace ST_CICS_CSharp.Tasks
{
    class Systematics_Limpiar
    {
        public static void Pantalla()
        {
            Presionar.Tecla(TnKey.Clear);
            Thread.Sleep(Global.tiempo);
        }
    }
}
