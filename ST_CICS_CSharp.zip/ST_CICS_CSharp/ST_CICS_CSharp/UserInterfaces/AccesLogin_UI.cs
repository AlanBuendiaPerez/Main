﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST_CICS_CSharp.UserInterfaces
{
    class AccesLogin_UI
    {
        public enum ObtenerInterbank { Posicion_Y = 22, Posicion_X = 14, Longitud = 9 }
        public enum Usuario { Posicion_Y = 10, Posicion_X = 68 }
        public enum Contraseña { Posicion_Y = 11, Posicion_X = 68 }
    }
}
