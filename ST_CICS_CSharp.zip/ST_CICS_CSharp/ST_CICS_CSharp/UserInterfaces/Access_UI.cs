﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class Access_UI
    {
        public enum ObtenerAccess { Posicion_Y = 6, Posicion_X = 2, Longitud = 6 }
        public enum Access { Posicion_Y = 7, Posicion_X = 1 }
    }
}
