﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class CicsApp_UI
    {
        public enum ObtenerSistemas { Posicion_Y = 1, Posicion_X = 28, Longitud = 8 }
        public enum Opcion { Posicion_Y = 20, Posicion_X = 44 }
    }
}
