﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class DEP_ComisionesMegaDetalle_UI
    {
        public enum ObtenerDepo { Posicion_Y = 02, Posicion_X = 74, Longitud = 05 }
        public enum ObtenerSinRegistros { Posicion_Y = 22, Posicion_X = 02, Longitud = 20 }

    }
}