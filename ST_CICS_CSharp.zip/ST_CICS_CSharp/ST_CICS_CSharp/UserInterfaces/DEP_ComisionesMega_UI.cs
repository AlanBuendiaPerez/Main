﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class DEP_ComisionesMega_UI
    {
        public enum ObtenerPendentesMega { Posicion_Y = 01 , Posicion_X = 37 , Longitud = 15 }
        public enum ObtenerMoneda { Posicion_Y = 04 , Posicion_X = 17 }
        public enum ObtenerOficina { Posicion_Y = 04, Posicion_X = 23 }
        public enum ObtenerCategoria { Posicion_Y = 04, Posicion_X = 29 }
        public enum ObtenerCuenta { Posicion_Y = 04, Posicion_X = 35 }
        public enum ObtenerCerosCuenta { Posicion_Y = 04, Posicion_X = 67, Longitud = 04 }
        public enum ObtenerConceptoOrden { Posicion_Y = 09, Posicion_X = 04, Longitud = 02 }
        public enum ObtenerCursorConcepto { Posicion_Y = 09, Posicion_X = 02 }
        public enum ObtenerSinRegistros { Posicion_Y = 22, Posicion_X = 02, Longitud = 20 }

    }
}