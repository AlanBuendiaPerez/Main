﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class DEP_Menu_UI
    {
        public enum ObtenerDEPOSITOS { Posicion_Y = 01 , Posicion_X = 28 , Longitud = 17 }
        public enum ObtenerCursor { Posicion_Y = 19 , Posicion_X = 30 }
    }
}