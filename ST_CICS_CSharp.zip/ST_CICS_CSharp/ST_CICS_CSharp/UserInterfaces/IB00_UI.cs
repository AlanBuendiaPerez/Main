﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class IB00_UI
    {
        public enum ObtenerConsulta { Posicion_Y = 20, Posicion_X = 59, Longitud = 8 }
        public enum Consulta { Posicion_Y = 20, Posicion_X = 69 }
    }
}