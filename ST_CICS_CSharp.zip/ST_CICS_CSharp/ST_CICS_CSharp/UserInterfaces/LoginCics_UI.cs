﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class LoginCics_UI
    {
        public enum ObtenerConsulta { Posicion_Y = 16, Posicion_X = 63, Longitud = 6 }
        public enum Usuario { Posicion_Y = 10, Posicion_X = 71 }
        public enum Contraseña { Posicion_Y = 11, Posicion_X = 71 }
    }
}
