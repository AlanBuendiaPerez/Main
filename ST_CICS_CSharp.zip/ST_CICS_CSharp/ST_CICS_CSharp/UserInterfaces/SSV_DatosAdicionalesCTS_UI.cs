﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SSV_DatosAdicionalesCTS_UI
    {
        public enum ObtenerDatosAdicionales { Posicion_Y = 01, Posicion_X = 28, Longitud = 17 }
        public enum ObtenerMoneda { Posicion_Y = 05, Posicion_X = 25 }
        public enum ObtenerOficina { Posicion_Y = 05, Posicion_X = 29 }
        public enum ObtenerCuenta { Posicion_Y = 05, Posicion_X = 37 }
        public enum ObtenerMaximoDisponible { Posicion_Y = 08, Posicion_X = 25 }
        public enum ObtenerSaldoDisponible { Posicion_Y = 09, Posicion_X = 25 }
        public enum ObtenerRemuneraciones { Posicion_Y = 10, Posicion_X = 25 }
        public enum ObtenerMonedaRemuneraciones { Posicion_Y = 11, Posicion_X = 25 }
        public enum ObtenerImporteAbono { Posicion_Y = 12, Posicion_X = 25 }
        public enum ObtenerFechaAbono { Posicion_Y = 13, Posicion_X = 25 }
        public enum ObtenerRemPrevia { Posicion_Y = 16, Posicion_X = 36 }
    }
}