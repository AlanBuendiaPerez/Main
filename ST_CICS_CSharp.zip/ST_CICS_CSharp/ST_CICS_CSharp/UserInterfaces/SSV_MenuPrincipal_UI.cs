﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SSV_MenuPrincipal_UI
    {
        public enum ObtenerAdministrativoSaving { Posicion_Y = 01, Posicion_X = 25, Longitud = 22 }
        public enum ObtenerOpcion { Posicion_Y = 16, Posicion_X = 36 }
    }
}