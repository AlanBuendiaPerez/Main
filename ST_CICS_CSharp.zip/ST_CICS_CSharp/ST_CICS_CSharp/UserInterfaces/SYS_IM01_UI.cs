﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_IM01_UI
    {
        public enum ObtenerNuevaImpacs { Posicion_Y = 02, Posicion_X = 38, Longitud = 15 }
        public enum ObtenerNumeroCuenta { Posicion_Y = 03, Posicion_X = 21, Longitud = 10 }
        public enum ObtenerTipoProducto { Posicion_Y = 04, Posicion_X = 22 }
    }
}