﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_RMAB_UI
    {
        public enum ObtenerConsultaRapida { Posicion_Y = 02, Posicion_X = 21, Longitud = 15 }
        
    }
}