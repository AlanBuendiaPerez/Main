﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_RMSA_UI
    {
        public enum ObtenerAperturaCuenta { Posicion_Y = 02, Posicion_X = 31, Longitud = 15 }
        public enum ObtenerPosicionSaving { Posicion_Y = 03, Posicion_X = 14 }
        public enum ObtenerPosicionImpacs { Posicion_Y = 03, Posicion_X = 03 }
        public enum ObtenerPosicionAplicativo { Posicion_Y = 07, Posicion_X = 03 }
        public enum ObtenerBanco { Posicion_Y = 07, Posicion_X = 50 }
        public enum ObtenerMoneda { Posicion_Y = 07, Posicion_X = 55 }
        public enum ObtenerOficina { Posicion_Y = 07, Posicion_X = 60 }
        public enum ObtenerCategoria { Posicion_Y = 07, Posicion_X = 65 }
        public enum ObtenerCodConexion { Posicion_Y = 08, Posicion_X = 17 }
        public enum ObtenerPosicion01 { Posicion_Y = 11, Posicion_X = 04 }
        public enum ObtenerPosicion02 { Posicion_Y = 13, Posicion_X = 04 }
        public enum ObtenerPosicion03 { Posicion_Y = 15, Posicion_X = 04 }
        public enum ObtenerPosicion04 { Posicion_Y = 17, Posicion_X = 04 }

        public enum ObtenerSesionTerminado { Posicion_Y = 24, Posicion_X = 35, Longitud = 16 }
    }
}