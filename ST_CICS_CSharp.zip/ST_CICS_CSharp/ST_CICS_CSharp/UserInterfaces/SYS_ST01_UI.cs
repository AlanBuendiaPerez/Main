﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_ST01_UI
    {
        public enum ObtenerNewAccount { Posicion_Y = 02, Posicion_X = 35, Longitud = 11 }
        public enum ObtenerNumeroCuenta { Posicion_Y = 03, Posicion_X = 22, Longitud = 10 }
        public enum ObtenerTipoProducto { Posicion_Y = 04, Posicion_X = 23 }
        public enum ObtenerAplicacion { Posicion_Y = 04, Posicion_X = 41 }
    }
}