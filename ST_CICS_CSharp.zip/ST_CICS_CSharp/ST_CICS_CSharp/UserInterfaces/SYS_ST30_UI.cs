﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_ST30_UI
    {
        public enum ObtenerRetencionST { Posicion_Y = 02, Posicion_X = 47, Longitud = 12 }
        public enum ObtenerCuenta { Posicion_Y = 03, Posicion_X = 18 }
        public enum ObtenerMoneda { Posicion_Y = 03, Posicion_X = 39 }
        public enum ObtenerOficina { Posicion_Y = 03, Posicion_X = 48 }
        public enum ObtenerCategoria { Posicion_Y = 03, Posicion_X = 57 }
        public enum ObtenerCodTransaccion { Posicion_Y = 06, Posicion_X = 39 }
        public enum ObtenerMonto { Posicion_Y = 07, Posicion_X = 58 }
        public enum ObtenerDescripcion { Posicion_Y = 09, Posicion_X = 15 }
        public enum ObtenerDias { Posicion_Y = 09, Posicion_X = 70 }
        public enum ObtenerProcesoCompleto { Posicion_Y = 24, Posicion_X = 41, Longitud = 19 }

    }
}