﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_ST80_UI
    {
        public enum ObtenerTransaccionesMonetarias { Posicion_Y = 02, Posicion_X = 27, Longitud = 24 }
        public enum ObtenerCuenta { Posicion_Y = 3, Posicion_X = 10 }
        public enum ObtenerMoneda { Posicion_Y = 3, Posicion_X = 52 }
        public enum ObtenerOficina { Posicion_Y = 3, Posicion_X = 61 }
        public enum ObtenerCategoria { Posicion_Y = 3, Posicion_X = 70 }
        public enum ObtenerTipoOperacion { Posicion_Y = 4, Posicion_X = 08 }
        public enum ObtenerTransaccion { Posicion_Y = 05, Posicion_X = 28 }
        public enum ObtenerMonto { Posicion_Y = 05, Posicion_X = 38 }
        public enum ObtenerDescripcion { Posicion_Y = 13, Posicion_X = 24 }
        //ObtenerCompleto - Proceso de Abono
        public enum ObtenerCompleto { Posicion_Y = 24, Posicion_X = 21, Longitud = 19 }
        public enum ObtenerExitoAbono { Posicion_Y = 24, Posicion_X = 21, Longitud = 34 }
        public enum ObtenerNueva { Posicion_Y = 24, Posicion_X = 21, Longitud = 19 }
        public enum ObtenerTipoDeb { Posicion_Y = 06, Posicion_X = 15 }
        //cancelacion
        public enum ObtenerProcesarCancelacion { Posicion_Y = 21, Posicion_X = 77 }

    }
}