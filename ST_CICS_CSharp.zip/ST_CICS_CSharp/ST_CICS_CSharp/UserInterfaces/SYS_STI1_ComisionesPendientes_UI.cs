﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_STI1_ComisionesPendientes_UI
    {
        public enum ObtenerComisionesPendientes { Posicion_Y = 02, Posicion_X = 29, Longitud = 22 }
        public enum ConceptoOrden { Posicion_Y = 08, Posicion_X = 04 , Longitud = 02 }
        public enum CursorOrden { Posicion_Y = 08, Posicion_X = 02 }
        public enum ObtenerSinRegistros { Posicion_Y = 24, Posicion_X = 02 , Longitud = 20 }

    }
}