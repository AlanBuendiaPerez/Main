﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_STI1_DealleComisionesPendientes_UI
    {
        public enum ObtenerDetalleComisiones { Posicion_Y = 02, Posicion_X = 26, Longitud = 21 }
        public enum ObtenerSinRegistros { Posicion_Y = 22, Posicion_X = 02 , Longitud = 20 }
    }
}