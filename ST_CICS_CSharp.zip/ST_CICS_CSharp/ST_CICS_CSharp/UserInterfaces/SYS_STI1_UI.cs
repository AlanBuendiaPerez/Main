﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_STI1_UI
    {
        public enum ObtenerInformacionDeCuentas { Posicion_Y = 02, Posicion_X = 30, Longitud = 22 }
        public enum ObtenerCuenta { Posicion_Y = 03, Posicion_X = 14 }
        public enum ObtenerMoneda { Posicion_Y = 03, Posicion_X = 39 }
        public enum ObtenerOficina { Posicion_Y = 03, Posicion_X = 48 }
        public enum ObtenerCategoria { Posicion_Y = 03, Posicion_X = 57 }
        
        //Obtener Cuenta no exite - Consulta de Cuenta
        public enum ObtenerCuentaNoExiste { Posicion_Y = 24, Posicion_X = 29, Longitud = 16 }

        //Obtener Estado Closed
        public enum ObtenerEstadoClosed { Posicion_Y = 16, Posicion_X = 02, Longitud = 06 }
    }
}