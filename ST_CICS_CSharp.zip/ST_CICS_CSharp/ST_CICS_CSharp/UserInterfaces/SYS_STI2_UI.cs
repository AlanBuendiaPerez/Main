﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SYS_STI2_UI
    {
        public enum ObtenerConsultaHistorico { Posicion_Y = 02, Posicion_X = 24, Longitud = 18 }
        public enum ObtenerCuenta { Posicion_Y = 03, Posicion_X = 18 }
        public enum ObtenerMoneda { Posicion_Y = 03, Posicion_X = 39 }
        public enum ObtenerOficina { Posicion_Y = 03, Posicion_X = 48 }
        public enum ObtenerCategoria { Posicion_Y = 03, Posicion_X = 57 }
        

        //Obtener Cuenta no exite - Consulta de Cuenta
        public enum ObtenerCuentaNoExiste { Posicion_Y = 24, Posicion_X = 29, Longitud = 16 }
        public enum ObtenerCuentaSinHistorico { Posicion_Y = 24, Posicion_X = 21, Longitud = 13 }

        //Obtener Last Page
        public enum ObtenerLastPage { Posicion_Y = 24, Posicion_X = 21, Longitud = 09 }
        public enum ObtenerNoAdelantar { Posicion_Y = 24, Posicion_X = 21, Longitud = 20 }

    }
}