﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class SeleccionApp_UI
    {
        public enum ObtenerAplicaciones { Posicion_Y = 1, Posicion_X = 24, Longitud = 9}
        public enum ObtenerSesionCerrada { Posicion_Y = 21, Posicion_X = 11, Longitud = 48}
        public enum ObtenerSesionAhoraCerrada { Posicion_Y = 21, Posicion_X = 11, Longitud = 44}
        public enum Command { Posicion_Y = 23, Posicion_X = 14 }
    }
}
