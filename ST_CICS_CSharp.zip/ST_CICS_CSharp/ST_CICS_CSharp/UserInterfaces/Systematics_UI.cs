﻿namespace ST_CICS_CSharp.UserInterfaces
{
    class Systematics_UI
    {
        public enum ObtenerMenu { Posicion_Y = 01 , Posicion_X = 02 , Longitud = 04 }
        public enum ObtenerCampoVacio { Posicion_Y = 01 , Posicion_X = 01 , Longitud = 80 }
        public enum ObtenerNoRegistrado { Posicion_Y = 22 , Posicion_X = 33 , Longitud = 21 }
        public enum Comando { Posicion_Y = 01 , Posicion_X = 15 }
    }
}
