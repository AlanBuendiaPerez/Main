﻿namespace Base.Utils
{
    class Configuracion
    {
        //Valores que se mantienen siempre
        public const string IP = "130.30.30.6";
        public const int PUERTO = 2023;
        public const string SISTEMA_OPERATIVO = "Windows";
        public static string PLATAFORMA = "CICS";
        public static string APLICATIVO = "Systematics";
        public const string URL_XRAY_AUTHENTICATE = "https://xray.cloud.getxray.app";
    }
}
