﻿using System.Linq;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.IO;
using TechTalk.SpecFlow;

namespace Base.Utils
{
    internal class Excel
    {
        public static void Escribir(string celda, string texto)
        {
            string archivo = $@"{Utilidad.RutaProyecto()}Resources\Data.xlsx";
            string hoja = ObtenerHoja();

            celda = celda[1..];
            string[] infoCelda = celda.Split(new char[] { '$' });
            string columna = infoCelda[0];
            uint fila = Convert.ToUInt32(infoCelda[1]);


            using SpreadsheetDocument document = SpreadsheetDocument.Open(archivo, true);
            IEnumerable<Sheet> sheets = document.WorkbookPart.Workbook.GetFirstChild<Sheets>().Elements<Sheet>().Where(s => s.Name == hoja);

            string relationshipId = sheets.First().Id.Value;
            WorksheetPart worksheetPart = (WorksheetPart)document.WorkbookPart.GetPartById(relationshipId);

            // Get the cell at the specified column and row.
            Cell cell = GetSpreadsheetCell(worksheetPart.Worksheet, columna, fila);
            cell.CellValue = new CellValue(texto);
            worksheetPart.Worksheet.Save();
        }
        private static Cell GetSpreadsheetCell(Worksheet worksheet, string columnName, uint rowIndex)
        {
            IEnumerable<Row> rows = worksheet.GetFirstChild<SheetData>().Elements<Row>().Where(r => r.RowIndex == rowIndex);
            IEnumerable<Cell> cells = rows.First().Elements<Cell>().Where(c => string.Compare(c.CellReference.Value, columnName + rowIndex, true) == 0);
            return cells.First();
        }
        public static string ObtenerHoja()
        {
            #pragma warning disable CS0618 // El tipo o el miembro están obsoletos
            string archivoFeature = $@"{Utilidad.RutaProyecto()}Features\{FeatureContext.Current.FeatureInfo.Title}.feature";
            string feature = File.ReadAllText(archivoFeature);
            feature = feature[..(feature.IndexOf(ScenarioContext.Current.ScenarioInfo.Title) - 12)];
            
            return feature[(feature.LastIndexOf("@DataSet:") + 9)..];
        }
    }
}
