﻿using System;
using System.Globalization;
using System.IO;
using TechTalk.SpecFlow;

namespace Base.Utils
{
    [Binding]
    public class GenerarJson
    {
        [BeforeFeature(Order = 2)]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            Global.rutaFeature = $@"{Utilidad.RutaProyecto()}Features\{featureContext.FeatureInfo.Title}.feature";
            string[] lineas = File.ReadAllLines(Global.rutaFeature);
            int contadorLinea = 1;

            foreach (string linea in lineas)
            {
                if (linea.Contains(featureContext.FeatureInfo.Title) & linea.Contains("Feature:"))
                {
                    Global.contadorTag = contadorLinea;
                    Global.ContenidoCucumberJson += "[{\n";
                    Global.ContenidoCucumberJson += $"\"line\": {contadorLinea},\n";
                    Global.ContenidoCucumberJson += "\"elements\": [\n";
                    break;
                }

                contadorLinea++;
            }
        }
        [BeforeScenario(Order = 2)]
        public static void BeforeScenario()
        {
            Global.tiempoScenarioInicial = Utilidad.GetNanoseconds();
        }

        [BeforeScenario(Order = 3)]
        public static void BeforeScenario(FeatureContext featureContext, ScenarioContext scenarioContext)
        {
            Global.ContenidoCucumberJson += "{\n";
            Global.ContenidoCucumberJson += $"\"start_timestamp\": \"{Global.fechaHoraIso8601}\",\n"; //variable sin valor Global.fechaHoraIso8601
            Global.ContenidoCucumberJson += "\"before\": [\n";
            Global.ContenidoCucumberJson += "{\n";
            Global.ContenidoCucumberJson += "\"result\": {\n";
            Global.ContenidoCucumberJson += $"\"duration\": {(Utilidad.GetNanoseconds() - Global.tiempoDriveInicial)},\n"; //variable sin valor Global.tiempoDriveInicial
            Global.ContenidoCucumberJson += "\"status\": \"passed\"\n";
            Global.ContenidoCucumberJson += "},\n";
            Global.ContenidoCucumberJson += "\"match\": {\n";
            Global.ContenidoCucumberJson += "\"location\": \""+ Global.nombreClase + "\"\n";
            Global.ContenidoCucumberJson += "}\n";
            Global.ContenidoCucumberJson += "},{\n";
            Global.ContenidoCucumberJson += "\"result\": {\n";
            Global.ContenidoCucumberJson += $"\"duration\": {(Utilidad.GetNanoseconds() - Global.tiempoScenarioInicial)},\n";//variable sin valor Global.tiempoScenarioInicial
            Global.ContenidoCucumberJson += "\"status\": \"passed\"\n";
            Global.ContenidoCucumberJson += "},\n";
            Global.ContenidoCucumberJson += "\"match\": {\n";
            Global.ContenidoCucumberJson += "\"location\": \"" + Global.nombreClase + "\"\n";
            Global.ContenidoCucumberJson += "}\n";
            Global.ContenidoCucumberJson += "}\n";
            Global.ContenidoCucumberJson += "],\n";

            string[] lineas = File.ReadAllLines(Global.rutaFeature);
            int contadorLinea = 1;
            
            foreach (string linea in lineas)
            {
                if (linea.Contains(scenarioContext.ScenarioInfo.Title) & (linea.Contains("Scenario:") || linea.Contains("Scenario Outline:")))
                {
                    Global.contadorTag = contadorLinea;
                    Global.lineaEscenario = contadorLinea;
                    Global.ContenidoCucumberJson += $"\"line\": {contadorLinea},\n";
                    break;
                }

                contadorLinea++;
            }

            Global.ContenidoCucumberJson += $"\"name\": \"{scenarioContext.ScenarioInfo.Title}\",\n";
            Global.ContenidoCucumberJson += "\"description\": \"\",\n";
            Global.ContenidoCucumberJson += $"\"id\": \"{featureContext.FeatureInfo.Title.ToLower().Replace(" ", "-")};{scenarioContext.ScenarioInfo.Title.Replace(' ', '-')}\",\n";

            Global.ScenarioJson += "\"type\":" + "\"scenario\",\n";
            Global.ScenarioJson += "\"keyword\":" + "\"Scenario\",\n";
        }

        [BeforeStep(Order = 0)]
        public void BeforeReportingSteps(ScenarioContext sc)
        {
            Global.tiempoStepsInicial = Utilidad.GetNanoseconds();
        }
        [AfterStep(Order = 2)]
        public static void AfterStep(ScenarioContext scenarioContext)
        {
            string stepType = scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();

            if (stepType.Equals("Given") & !Global.featureAnd)
            {
                Global.ScenarioJson += "\"steps\": [\n";
                Global.featureAnd = true;
            }

            Global.ScenarioJson += "{\n";
            Global.ScenarioJson += "\"embeddings\":[\n";

            if (Global.imagenes.Count > 0)
            {
                int contadorImagen = 1;

                foreach (string imagen in Global.imagenes)
                {
                    byte[] imageArray = File.ReadAllBytes(imagen);
                    string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                    Global.ScenarioJson += "{\n";
                    Global.ScenarioJson += $"\"data\": \"{base64ImageRepresentation}\",\n";
                    Global.ScenarioJson += "\"mime_type\": \"image/png\",\n";
                    Global.ScenarioJson += "\"name\": \"evidence\"\n";

                    if(Global.imagenes.Count == contadorImagen)
                    {
                        Global.ScenarioJson += "}\n";
                    }
                    else
                    {
                        Global.ScenarioJson += "},\n";
                    }

                    contadorImagen++;
                }

                Global.imagenes.Clear();
            }
            else
            {
                Global.ScenarioJson += "{\n";
                Global.ScenarioJson += "\"data\": \"\",\n";
                Global.ScenarioJson += "\"mime_type\": \"image/png\",\n";
                Global.ScenarioJson += "\"name\": \"evidence\"\n";
                Global.ScenarioJson += "}\n";
            }
            
            Global.ScenarioJson += "],\n";
            Global.ScenarioJson += "\"result\": {\n";

            if (scenarioContext.TestError == null)
            {
                Global.estadoResult = "passed";
                
                Global.ScenarioJson += $"\"duration\": {(Utilidad.GetNanoseconds() - Global.tiempoStepsInicial)},\n";//Valor fijo
                Global.ScenarioJson += $"\"status\": \"{Global.estadoResult}\"\n";
            }
            else
            {
                Global.estadoResult = "failed";
                Global.ScenarioJson += $"\"error_message\": \"{scenarioContext.TestError.Message}\",\n";
                Global.ScenarioJson += $"\"duration\": {(Utilidad.GetNanoseconds() - Global.tiempoStepsInicial)},\n";//Valor fijo
                Global.ScenarioJson += $"\"status\": \"{Global.estadoResult}\"\n";
            }

            Global.ScenarioJson += "},\n";

            Global.lineaStep++;

            Global.ScenarioJson += $"\"line\": {(Global.lineaStep + Global.lineaEscenario)},\n";
            Global.ScenarioJson += $"\"name\": \"{scenarioContext.StepContext.StepInfo.Text}\",\n";
            Global.ScenarioJson += "\"match\": {\n";
            Global.ScenarioJson += $"\"location\": \"{Global.paqueteStepDefinition}\"\n"; //De donde proviene el valor
            Global.ScenarioJson += "},\n";
            Global.ScenarioJson += $"\"keyword\": \"{stepType}\"\n";
            Global.ScenarioJson += "},\n";
        }
        [AfterScenario(Order = 1)]
        public static void AfterScenario(FeatureContext featureContext, ScenarioContext scenarioContext)
        {
            Global.featureAnd = false;

            Global.tituloFeature = featureContext.FeatureInfo.Title;

            Global.ScenarioJson = Global.ScenarioJson.Substring(0, Global.ScenarioJson.LastIndexOf(","));
            Global.ScenarioJson += "],\n";
            Global.ScenarioJson += "\"tags\": [\n";

            string[] lineas = File.ReadAllLines(Global.rutaFeature);
            string[] tagsFeature = lineas[0].Split(new char[] { ' ' });

            int contadorFeature = 1;
            foreach (string tag in tagsFeature)
            {
                Global.ScenarioJson += "{\n";
                Global.ScenarioJson += $"\"name\": \"{tag}\"\n";
                if (contadorFeature == tagsFeature.Length)
                {
                    Global.ScenarioJson += "}";
                }
                else
                {
                    Global.ScenarioJson += "},";
                }

                contadorFeature++;
            }

            int contadorTags = 1;

            foreach (string linea in lineas)
            {
                if (linea.Contains(scenarioContext.ScenarioInfo.Title))
                {
                    string[] tagEscenario = lineas[contadorTags - 2].Split(new char[] { ' ' });
                    int contadorEscenario = 1;

                    foreach (var tag in tagEscenario)
                    {
                        if (!tag.Trim().Contains("Data"))
                        {
                            Global.ScenarioJson += ",\n{\n";
                            Global.ScenarioJson += $"\"name\": \"{tag.Trim()}\"\n";
                            Global.ScenarioJson += "}\n";
                        }

                        if (contadorEscenario == tagEscenario.Length)
                        {
                            Global.ScenarioJson += "]},\n";
                        }

                        contadorEscenario++;
                    }
                    break;
                }

                contadorTags++;
            }
        }

        [AfterScenario(Order = 2)]
        public static void AfterScenario()
        {
            Global.ContenidoCucumberJson += "\"after\": [\n";
            Global.ContenidoCucumberJson += "{\n";
            Global.ContenidoCucumberJson += "\"result\": {\n";
            Global.ContenidoCucumberJson += $"\"duration\": {(Global.tiempoCapturaFinal - Global.tiempoCapturaInicial)},\n";//variable sin valor Global.tiempoCapturaFinal y Global.tiempoCapturaInicial
            Global.ContenidoCucumberJson += $"\"status\": \"{Global.estadoResult}\"\n";
            Global.ContenidoCucumberJson += "},\n";
            Global.ContenidoCucumberJson += "\"match\": {\n";
            Global.ContenidoCucumberJson += "\"location\": \"com.demo.hook.Hooks.failed()\"\n";
            Global.ContenidoCucumberJson += "}\n";
            Global.ContenidoCucumberJson += "},{\n";
            Global.ContenidoCucumberJson += "\"result\": {\n";
            Global.ContenidoCucumberJson += $"\"duration\": {(Global.tiempoCerrarDriveFinal - Global.tiempoCerrarDriveInicial)},\n";//variable sin valor Global.tiempoCerrarDriveFinal y Global.tiempoCerrarDriveInicial
            Global.ContenidoCucumberJson += "\"status\":" + "\"" + Global.estadoResult + "\"\n";
            Global.ContenidoCucumberJson += "},\n";
            Global.ContenidoCucumberJson += "\"match\":" + "{\n";
            Global.ContenidoCucumberJson += "\"location\":" + "\"ccom.demo.hook.Hooks.tearsDown()\"\n";
            Global.ContenidoCucumberJson += "}\n";
            Global.ContenidoCucumberJson += "}\n";
            Global.ContenidoCucumberJson += "],\n";
        }
        
        //Revisar
        [AfterScenario(Order = 3)]
        public static void AfterScenarioJson()
        {
            Global.ContenidoCucumberJson += Global.ScenarioJson;
            Global.ScenarioJson = string.Empty;
        }

        [AfterTestRun(Order = 2)]
        public static void AfterTestRunJson()
        {
            string featureCapital = CultureInfo.InvariantCulture.TextInfo.ToTitleCase(Global.tituloFeature);

            Global.ContenidoCucumberJson = Global.ContenidoCucumberJson.Substring(0, Global.ContenidoCucumberJson.LastIndexOf(","));
            Global.ContenidoCucumberJson += "],\n";
            Global.ContenidoCucumberJson += $"\"name\": \"{featureCapital}\",\n";
            Global.ContenidoCucumberJson += "\"description\": \"\",\n";
            Global.ContenidoCucumberJson += $"\"id\": \"{Global.tituloFeature.ToLower().Replace(" ", "-")}\",\n";
            Global.ContenidoCucumberJson += "\"keyword\": \"Feature\",\n";
            Global.ContenidoCucumberJson += $"\"uri\": \"file:feature/{Global.tituloFeature.Replace(" ", "%20")}.feature\",\n";
            Global.ContenidoCucumberJson += "\"tags\": [\n";

            string[] lineas = File.ReadAllLines(Global.rutaFeature);

            string[] nameTagsLines = lineas[0].Split(new char[] { ' ' });
            for (int i = 0; i < nameTagsLines.Length; i++)
            {
                Global.ContenidoCucumberJson += "{\n";
                Global.ContenidoCucumberJson += $"\"name\": \"{nameTagsLines[i]}\",\n";
                Global.ContenidoCucumberJson += "\"type\": \"Tag\",\n";
                Global.ContenidoCucumberJson += "\"location\": {\n";
                Global.ContenidoCucumberJson += "\"line\": 1,\n";
                Global.ContenidoCucumberJson += "\"column\": 1\n";
                Global.ContenidoCucumberJson += "}\n";

                if (i + 1 == nameTagsLines.Length)
                {
                    Global.ContenidoCucumberJson += "}\n";
                }
                else
                {
                    Global.ContenidoCucumberJson += "},\n";
                }
            }

            Global.ContenidoCucumberJson += "]\n";
            Global.ContenidoCucumberJson += "}]\n";

            Utilidad.GenerarArchivoCucumberJson();
        }
    }
}