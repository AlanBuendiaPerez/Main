﻿using System.Collections.Generic;
using iTextSharp.text;
using Open3270;

namespace Base.Utils
{
    class Global
    {
        public static TNEmulator terminal = new();
        public static string capturaPantalla = string.Empty;
        public static string rutaGeneral = string.Empty;
        public static string rutaResultados = string.Empty;
        public static string rutaEvidencia = string.Empty;
        public static string nombreClase = string.Empty;
        public static string evidenciaImagen = string.Empty;
        public static List<string> imagenes = new();
        public static string rutaLogDiario = string.Empty;
        public static string rutaLogEjecucion = string.Empty;
        public static int contadorEvidencia = 1;
        public static int numeroEjecucion = 0;
        public static int numeroTest = 0;
        public static List<string> resultado = new();

        //Información que viene del orquestador ==>
        public static string responsable = string.Empty;
        public static int tiempo = 0;
        public static string clientID = string.Empty;
        public static string clientSecret = string.Empty;
        public static string usuarioCics = string.Empty;
        public static string contraseñaCics = string.Empty;
        //Información que viene del orquestador <==

        //Aparto para Xray==>
        public static int contadorTag = 0;
        public static int lineaStep = 0;
        public static int lineaEscenario = 0;
        public static string valFeatureInfo = string.Empty;
        public static long tiempoDriveInicial = 0;
        public static long tiempoScenarioInicial = 0;
        public static string fechaHoraIso8601 = string.Empty;
        public static long tiempoCapturaInicial = 0;
        public static long tiempoCapturaFinal = 0;
        public static long tiempoCapturaResultado = 0;
        public static long tiempoCerrarDriveInicial = 0;//Sin asignacion de valor
        public static long tiempoCerrarDriveFinal = 0;//Sin asignacion de valor

        public static long tiempoStepsInicial = 0;
        public static string estadoResult = string.Empty;
        public static string paqueteStepDefinition = string.Empty;
        public static string mensajeJson = string.Empty;
        public static string tituloFeature = string.Empty;
        public static string rutaFeature = string.Empty;
        public static bool featureAnd = false;
        public static string ContenidoCucumberJson = string.Empty;
        public static string ScenarioJson = string.Empty;
        public static string apiToken = string.Empty;
        //Aparto para Xray <==

        //Generar PDF
        public static int numSalto = 0;
        public static Document documento;
    }
}
