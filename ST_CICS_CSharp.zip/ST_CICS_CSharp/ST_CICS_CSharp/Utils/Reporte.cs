﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Gherkin.Model;
using AventStack.ExtentReports.Reporter;
using System;
using System.IO;
using TechTalk.SpecFlow;

namespace Base.Utils
{
    [Binding]
    internal class Reporte
    {
        private static ExtentReports extentReports;
        private static ExtentTest feature, scenario, step;

        [BeforeTestRun (Order = 3)]
        public static void BeforeTestRun()
        {
            ExtentHtmlReporter extentHtmlReporter = new(Global.rutaResultados);
            extentHtmlReporter.Config.Theme = AventStack.ExtentReports.Reporter.Configuration.Theme.Dark;
            extentHtmlReporter.Config.DocumentTitle = "Reporte";

            extentReports = new();
            extentReports.AttachReporter(extentHtmlReporter);
            extentReports.AddSystemInfo("Plataforma", Configuracion.PLATAFORMA);
            extentReports.AddSystemInfo("Aplicativo", Configuracion.APLICATIVO);
            extentReports.AddSystemInfo("Sistema Operativo", Configuracion.SISTEMA_OPERATIVO);
        }

        [BeforeFeature (Order = 0)]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            string funcionalidad = featureContext.FeatureInfo.Title;

            feature = extentReports.CreateTest<Feature>(funcionalidad);
            feature.AssignAuthor(Global.responsable);
            feature.AssignCategory(funcionalidad);

            Global.rutaLogDiario = Global.rutaGeneral + "LogDiario.txt";
        }

        [BeforeScenario (Order = 0)]
        public static void BeforeScenario(ScenarioContext scenarioContext)
        {
            scenario = feature.CreateNode<Scenario>(scenarioContext.ScenarioInfo.Title);
            Global.rutaLogEjecucion = Global.rutaResultados + "Log.txt";
            Utilidad.RegistrarLog($"Scenario - {scenarioContext.ScenarioInfo.Title} => Iniciado");
        }

        [BeforeStep]
        public static void BeforeStep(ScenarioContext scenarioContext)
        {
            string stepType = scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();
            Utilidad.RegistrarLog($"{stepType} - {ScenarioStepContext.Current.StepInfo.Text} => Iniciado");
        }

        [AfterStep (Order = 0)]
        public static void AfterStep(ScenarioContext scenarioContext)
        {
            string stepType = scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();

            step = scenario.CreateNode(new GherkinKeyword(stepType), ScenarioStepContext.Current.StepInfo.Text);
            if (scenarioContext.TestError == null)
            {
                step.Pass("Passed");
                Utilidad.RegistrarLog($"{stepType} - {ScenarioStepContext.Current.StepInfo.Text} => Finalizado - { ScenarioStepContext.Current.Status}");
            }
            else if (scenarioContext.TestError != null)
            {
                string error = scenarioContext.TestError.Message;
                step.Fail(error);
                Utilidad.RegistrarLog($"{stepType} - {ScenarioStepContext.Current.StepInfo.Text} => Finalizado - { ScenarioStepContext.Current.Status} : {error}");
            }

            if (Global.imagenes.Count > 0)
            {
                foreach (string imagen in Global.imagenes)
                {
                    byte[] imageArray = File.ReadAllBytes(imagen);
                    string base64ImageRepresentation = Convert.ToBase64String(imageArray);
                    step.AddScreenCaptureFromBase64String(base64ImageRepresentation);
                }
            }
        }

        [AfterScenario (Order = 0)]
        public static void AfterScenario(ScenarioContext scenarioContext)
        {
            Utilidad.RegistrarLog($"Scenario - {scenarioContext.ScenarioInfo.Title} => Finalizado " + scenarioContext.ScenarioExecutionStatus);
            Global.contadorEvidencia = 1;
            Global.resultado.Clear();
        }

        [AfterTestRun (Order = 0)]
        public static void AfterTestRun()
        {
            extentReports.Flush();
        }
    }
}
