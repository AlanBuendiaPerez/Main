﻿using System;
using System.IO;
using TechTalk.SpecFlow;

namespace Base.Utils
{
    [Binding]
    internal class ReportePDF
    {
        [BeforeFeature (Order = 1)]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            string funcionalidad = featureContext.FeatureInfo.Title;

            int resultadoLineaDisponible = 46 - Global.numSalto;
            
            if (resultadoLineaDisponible <= 20)
            {
                for (int i = resultadoLineaDisponible; i <= 46; i++)
                {
                    if (Global.numSalto == 46)
                    {
                        Global.numSalto = 0;
                        break;
                    }
                    Utilidad.AgregarTextoPDF("\n");
                    Global.numSalto++;
                }
            }

            Utilidad.AgregarTextoPDF("Feature " + funcionalidad);
            Global.numSalto++;

        }
        
        [BeforeScenario (Order = 1)]
        public static void BeforeScenario(ScenarioContext scenarioContext)
        {
            int resultadoLineaDisponible = 46 - Global.numSalto;

            if (resultadoLineaDisponible <= 20)
            {
                for (int i = resultadoLineaDisponible; i <= 46; i++)
                {
                    if (Global.numSalto == 46)
                    {
                        Global.numSalto = 0;
                        break;
                    }
                    Utilidad.AgregarTextoPDF("\n");
                    Global.numSalto++;
                }
            }

            Utilidad.AgregarTextoPDF("Scenario " + scenarioContext.ScenarioInfo.Title);
            Global.numSalto++;
        }

        [AfterStep (Order = 1)]
        public static void AfterStep(ScenarioContext scenarioContext)
        {
            int resultadoLineaDisponible = 46 - Global.numSalto;
            string stepType = scenarioContext.StepContext.StepInfo.StepDefinitionType.ToString();

            string stepTexto = stepType + " " + ScenarioStepContext.Current.StepInfo.Text;
            if (stepTexto.Length >= 86)
            {
                Global.numSalto++;
            }

            if (resultadoLineaDisponible <= 20)
            {
                for (int i = resultadoLineaDisponible; i <= 46; i++)
                {
                    if (Global.numSalto == 46)
                    {
                        Global.numSalto = 0;
                        break;
                    }
                    Utilidad.AgregarTextoPDF("\n");
                    Global.numSalto++;
                }
            }

            if (scenarioContext.TestError == null)
            {
                Utilidad.AgregarTextoPDF(stepTexto);
                Global.numSalto++;
            }
            else if (scenarioContext.TestError != null)
            {
                Utilidad.AgregarTextoPDF(stepTexto);
                Global.numSalto++;
            }

            if (Global.imagenes.Count > 0)
            {
                foreach (string imagen in Global.imagenes)
                {
                    byte[] imageArray = File.ReadAllBytes(imagen);
                    string base64ImageRepresentation = Convert.ToBase64String(imageArray);

                    Utilidad.ReportePDF(imagen);
                    Global.numSalto += 19;


                    int resultadoDisponible = 46 - Global.numSalto;

                    if (resultadoDisponible <= 20)
                    {
                        for (int i = resultadoDisponible; i <= 46; i++)
                        {
                            if (Global.numSalto == 46)
                            {
                                Global.numSalto = 0;
                                break;
                            }
                            Utilidad.AgregarTextoPDF("\n");
                            Global.numSalto++;
                        }
                    }

                }
            }
        }

        [AfterTestRun (Order = 1)]
        public static void AfterTestRun()
        {
            Utilidad.CerrarPdf();
        }
    }
}
