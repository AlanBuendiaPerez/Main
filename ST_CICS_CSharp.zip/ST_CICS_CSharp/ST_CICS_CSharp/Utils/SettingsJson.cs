﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Dynamic;
using System.IO;
using System.Text;

namespace Base.Utils
{
    class SettingsJson
    {
        public static void AsignarSettings()
        {
            string json = $@"{Utilidad.RutaProyecto()}settings.json";
            string jsonStream = File.ReadAllText(json, Encoding.Latin1);

            dynamic settings = JsonConvert.DeserializeObject<ExpandoObject>(jsonStream, new ExpandoObjectConverter());

            Global.responsable = settings.responsable;
            Global.tiempo = settings.tiempo_espera == "" ? 0 : Convert.ToInt32(settings.tiempo_espera);
            Global.clientID = settings.client_id;
            Global.clientSecret = settings.client_secret;

            foreach (var item in settings.credenciales)
            {
                Global.usuarioCics = item.usuario_cics;
                Global.contraseñaCics = item.password_cics;
            }
        }
    }
}
