﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Threading;
using Font = System.Drawing.Font;
using IFont = iTextSharp.text.Font;
using IImage = iTextSharp.text.Image;

namespace Base.Utils
{
    class Utilidad
    {
        public static void Servidor()
        {
            Global.terminal.Config.UseSSL = false;
            Global.terminal.Config.TermType = "IBM-3278-2-E";
            Global.terminal.Connect(Configuracion.IP, Configuracion.PUERTO, string.Empty);

            Thread.Sleep(Global.tiempo);
        }
        public static void AgregarTextoPDF(string sms)
        {
            BaseFont fuente = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, true);
            IFont colorTitulo = new(fuente, 10f, IFont.NORMAL, new BaseColor(0, 0, 0));
            Global.documento.Add(new Paragraph(sms, colorTitulo));
        }
        public static void ReportePDF(string img)
        {
            var nombreimagen = img;
            IImage foto = IImage.GetInstance(nombreimagen);
            foto.BorderWidth = 0;
            foto.Alignment = Element.ALIGN_CENTER;
            foto.ScaleAbsoluteWidth(480);
            foto.ScaleAbsoluteHeight(270);

            float percentage;
            percentage = 500 / foto.Width;
            foto.ScalePercent(percentage * 100);

            Global.documento.Add(IImage.GetInstance(foto));
        }
        public static void CerrarPdf()
        {
            Global.documento.Close();
        }
        public static void CapturarEvidenciaCics()
        {
            Global.capturaPantalla = string.Empty;
            string texto = Global.terminal.CurrentScreenXML.Dump();

            for (int i = 0; i <= 23; i++)
            {
                Global.capturaPantalla = i == 23 ? texto.Remove(1919, 90).ToString() : texto.Remove(80 + (80 * i), 4).ToString();
            }

#pragma warning disable CA1416 // Compatibilidad solo para windows
            if (Global.capturaPantalla.Trim().Length > 0)
            {
                OcultarCredenciales(Global.contraseñaCics);

                string text = Global.capturaPantalla;
                Bitmap bitmap = new(1, 1);
                Font font = new(FontFamily.GenericMonospace, 25, FontStyle.Regular, GraphicsUnit.Pixel);
                Graphics graphics = Graphics.FromImage(bitmap);
                int width = (int)graphics.MeasureString(text, font).Width;
                int height = (int)graphics.MeasureString(text, font).Height;
                bitmap = new Bitmap(bitmap, new Size(width, height));
                graphics = Graphics.FromImage(bitmap);
                graphics.Clear(Color.Black);
                graphics.DrawString(text, font, new SolidBrush(Color.White), 0, 0);
                graphics.Flush();
                graphics.Dispose();

                Global.evidenciaImagen = Global.rutaEvidencia + Global.contadorEvidencia + ".png";

                int ancho = bitmap.Width;
                int alto = bitmap.Height;
                int leftShift = 50;
                int rightShift = 80;
                int topShift = ancho - 50;
                int bottomShift = alto - 100;

                System.Drawing.Rectangle rectOrig = new(leftShift, rightShift, topShift, bottomShift);

                Bitmap CroppedImage = CropImage(bitmap, rectOrig);
                CroppedImage.Save(Global.evidenciaImagen, ImageFormat.Png);
                bitmap.Dispose();

                Global.contadorEvidencia++;
                Global.imagenes.Add(Global.evidenciaImagen);
            }
            else
            {
                Global.capturaPantalla = string.Empty;
            }
        }
        public static Bitmap CropImage(Bitmap source, System.Drawing.Rectangle section)
        {
            Bitmap bmp = new(section.Width, section.Height);
            Graphics g = Graphics.FromImage(bmp);

            g.DrawImage(source, 0, 0, section, GraphicsUnit.Pixel);

            return bmp;
        }
        public static void OcultarCredenciales(string credencial)
        {
            string texto = string.Empty;
            for (int i = 1; i <= credencial.Length; i++)
            {
                texto += "*";
            }

            Global.capturaPantalla = Global.capturaPantalla.Replace(credencial, texto);
        }
        public static void RegistrarLog(string texto)
        {
            StreamWriter file = new(Global.rutaLogDiario, true);
            file.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss") + " " + texto);
            file.Close();

            file = new(Global.rutaLogEjecucion, true);
            file.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss") + " " + texto);
            file.Close();
        }
        public static string NombreClase(Type CLASS)
        {
            string NAMESPACE = CLASS.Namespace;
            string CLASS_NAME = CLASS.Name;
            StackTrace stackTrace = new();
            StackFrame stackFrame = stackTrace.GetFrame(1);

            return NAMESPACE + "." + CLASS_NAME + "." + stackFrame.GetMethod().Name;
        }
        public static void CrearCarpeta(string ruta)
        {
            if (!Directory.Exists(ruta))
            {
                _ = Directory.CreateDirectory(ruta);
            }
        }
        public static string RutaProyecto()
        {
            string directorioActual = Directory.GetCurrentDirectory();
            return directorioActual[..(directorioActual.IndexOf("\\bin") + 1)];
        }
        public static void GenerarRutaEvidencias()
        {
            Global.numeroTest++;
            string nroTest = "000" + Global.numeroTest;
            Global.rutaEvidencia = Global.rutaResultados + @"Evidencias\CP" + nroTest[^3..] + @"\";

            CrearCarpeta(Global.rutaEvidencia);
        }
        public static long GetNanoseconds()
        {
            double timestamp = Stopwatch.GetTimestamp();
            double nanoseconds = 1_000_000_000.0 * timestamp / Stopwatch.Frequency;
            return (long)nanoseconds;
        }
        public static void EliminarArchivo(string ruta)
        {
            if (File.Exists(ruta))
            {
                File.Delete(ruta);
            }
        }
        public static void GenerarArchivoCucumberJson()
        {
            string ruta = $@"{RutaProyecto()}cucumber.json";

            EliminarArchivo(ruta);

            StreamWriter file = new(ruta, true);
            file.Write(Global.ContenidoCucumberJson.Trim());
            file.Close();
        }
    }
}