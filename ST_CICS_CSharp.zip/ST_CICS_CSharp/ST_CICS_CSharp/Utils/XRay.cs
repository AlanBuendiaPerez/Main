﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.IO;

namespace Base.Utils
{
    class XRay
    {
        public static async Task ApiAuth()
        {
            using (var client = new HttpClient())
            {
                string strText = "{\"client_id\": \"" + Global.clientID + "\",\"client_secret\": \"" + Global.clientSecret + "\"}";
                StringContent stringContent = new(strText, UnicodeEncoding.UTF8, "application/json");
                client.BaseAddress = new Uri(Configuracion.URL_XRAY_AUTHENTICATE);
                HttpResponseMessage response = await client.PostAsync("/api/v1/authenticate", stringContent);

                int statusCode = (int)response.StatusCode;
                if (statusCode != 200)
                {
                    throw new Exception("No se pudo extraer el token de Jira");
                }

                string responseJson = await response.Content.ReadAsStringAsync();
                Global.apiToken = responseJson.Substring(1, responseJson.Length - 2);
            }
        }
        public static async Task ApiImportCucumber()
        {
            using (var client = new HttpClient())
            {
                string strText = File.ReadAllText($@"{Utilidad.RutaProyecto()}cucumber.json");

                StringContent stringContent = new(strText, UnicodeEncoding.UTF8, "application/json");

                client.BaseAddress = new Uri(Configuracion.URL_XRAY_AUTHENTICATE);
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + Global.apiToken);
                HttpResponseMessage response = await client.PostAsync("/api/v1/import/execution/cucumber", stringContent);

                int statusCode = (int)response.StatusCode;
                if (statusCode != 200)
                {
                    throw new Exception("No se pudo realizar la carga en Jira");
                }

                string responseJson = await response.Content.ReadAsStringAsync();
            }
        }
    }
}
